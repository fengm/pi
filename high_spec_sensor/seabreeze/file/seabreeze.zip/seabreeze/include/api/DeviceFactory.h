/***************************************************//**
 * @file    DeviceFactory.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This class allows Device class instances to be created
 * using just the name of the class as a string.
 *
 */
#ifndef SEABREEZE_DEVICE_FACTORY_H
#define SEABREEZE_DEVICE_FACTORY_H

/* Includes */
#include <string>
#include <map>
#include "common/devices/Device.h"

namespace seabreeze {

    class DeviceFactory {

    public:
        static DeviceFactory* getInstance();
        static DeviceFactory* instance;
        static void shutdown();

        Device *create(const std::string& name);
        Device *create(int index);
        int getNumberOfDeviceTypes();

    private:
        typedef Device *(*creatorFunction)(void);
        DeviceFactory();
        std::map<std::string, creatorFunction> nameToCreator;
    };


} /* end namespace */

#endif /* SEABREEZE_DEVICE_FACTORY_H */

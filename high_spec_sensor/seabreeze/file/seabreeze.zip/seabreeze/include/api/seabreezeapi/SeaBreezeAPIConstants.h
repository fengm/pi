/***************************************************//**
 * @file    SeaBreezeAPIConstants.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This file defines constants for use with SeaBreeze API
 * implementations.
 *
 *******************************************************/
#ifndef SEABREEZEAPICONSTANTS_H
#define SEABREEZEAPICONSTANTS_H

/* Constants */
#define ERROR_SUCCESS               0
#define ERROR_INVALID_ERROR         1
#define ERROR_NO_DEVICE             2
#define ERROR_FAILED_TO_CLOSE       3
#define ERROR_NOT_IMPLEMENTED       4
#define ERROR_FEATURE_NOT_FOUND     5
#define ERROR_TRANSFER_ERROR        6
#define ERROR_BAD_USER_BUFFER       7

#endif /* SEABREEZEAPICONSTANTS_H */

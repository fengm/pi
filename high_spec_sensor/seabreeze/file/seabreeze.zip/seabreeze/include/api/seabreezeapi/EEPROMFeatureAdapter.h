/***************************************************//**
 * @file    EEPROMFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze EEPROMFeatureInterface instances.
 *
 *******************************************************/

#ifndef EEPROMFEATUREADAPTER_H
#define EEPROMFEATUREADAPTER_H

/* Includes */
#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/eeprom_slots/EEPROMSlotFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class EEPROMFeatureAdapter
                : public FeatureAdapterTemplate<EEPROMSlotFeatureInterface> {
        public:
            EEPROMFeatureAdapter(EEPROMSlotFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~EEPROMFeatureAdapter();

            /* EEPROM functions */
            int readEEPROMSlot(int *errorCode, int slotNumber,
                    unsigned char *buffer, int bufferLength);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* EEPROMFEATUREADAPTER_H */

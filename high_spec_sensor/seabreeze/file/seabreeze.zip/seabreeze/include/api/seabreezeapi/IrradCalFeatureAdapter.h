/***************************************************//**
 * @file    IrradCalFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze IrradCalFeatureInterface instances.
 *
 *******************************************************/

#ifndef IRRADCALFEATUREADAPTER_H
#define IRRADCALFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/irradcal/IrradCalFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class IrradCalFeatureAdapter
                : public FeatureAdapterTemplate<IrradCalFeatureInterface> {
        public:
            IrradCalFeatureAdapter(IrradCalFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~IrradCalFeatureAdapter();

            int readIrradCalibration(int *errorCode, float *buffer,
                    int bufferLength);
            int writeIrradCalibration(int *errorCode, float *buffer,
                    int bufferLength);
            int hasIrradCollectionArea(int *errorCode);
            float readIrradCollectionArea(int *errorCode);
            void writeIrradCollectionArea(int *errorCode, float area);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* IRRADCALFEATUREADAPTER_H */

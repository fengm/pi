/***************************************************//**
 * @file    StrobeLampFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze StrobeLampFeatureInterface instances.
 *
 *******************************************************/

#ifndef STROBELAMPFEATUREADAPTER_H
#define STROBELAMPFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/light_source/StrobeLampFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class StrobeLampFeatureAdapter
                : public FeatureAdapterTemplate<StrobeLampFeatureInterface> {
        public:
            StrobeLampFeatureAdapter(StrobeLampFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~StrobeLampFeatureAdapter();

            void setStrobeLampEnable(int *errorCode, bool enable);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* STROBELAMPFEATUREADAPTER_H */

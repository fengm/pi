/***************************************************//**
 * @file    SerialNumberFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze SerialNumberFeatureInterface instances.
 *
 *******************************************************/

#ifndef SERIALNUMBERFEATUREADAPTER_H
#define SERIALNUMBERFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/serial_number/SerialNumberFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class SerialNumberFeatureAdapter
                : public FeatureAdapterTemplate<SerialNumberFeatureInterface> {
        public:
            SerialNumberFeatureAdapter(SerialNumberFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~SerialNumberFeatureAdapter();

            int getSerialNumber(int *errorCode, char *buffer, int buffer_length);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* SERIALNUMBERFEATUREADAPTER_H */

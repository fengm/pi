/***************************************************//**
 * @file    NonlinearityCoeffsFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze NonlinearityCoeffFeatureInterface instances.
 *
 *******************************************************/

#ifndef NONLINEARITYCOEFFSFEATUREADAPTER_H
#define NONLINEARITYCOEFFSFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/nonlinearity/NonlinearityCoeffsFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class NonlinearityCoeffsFeatureAdapter
                : public FeatureAdapterTemplate<NonlinearityCoeffsFeatureInterface> {
        public:
            NonlinearityCoeffsFeatureAdapter(NonlinearityCoeffsFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~NonlinearityCoeffsFeatureAdapter();

            int readNonlinearityCoeffs(int *errorCode, double *buffer,
                    int bufferLength);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* NONLINEARITYCOEFFSFEATUREADAPTER_H */

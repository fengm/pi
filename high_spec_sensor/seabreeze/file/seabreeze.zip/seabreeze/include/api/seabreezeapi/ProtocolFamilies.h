/***************************************************//**
 * @file    ProtocolFamilies.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds
 * protocols (e.g. OOI, OBP) generically.
 *
 *******************************************************/

#ifndef PROTOCOLFAMILIES_H
#define PROTOCOLFAMILIES_H

#include "common/protocols/ProtocolFamily.h"
#include <vector>

namespace seabreeze {
    namespace api {

        class UndefinedProtocolFamily : public ProtocolFamily {
        public:
            UndefinedProtocolFamily();
            virtual ~UndefinedProtocolFamily();
        };

        class OOIProtocolFamily : public ProtocolFamily {
        public:
            OOIProtocolFamily();
            virtual ~OOIProtocolFamily();
        };

        class OceanBinaryProtocolFamily : public ProtocolFamily {
        public:
            OceanBinaryProtocolFamily();
            virtual ~OceanBinaryProtocolFamily();
        };

        class JazMessagingProtocolFamily : public ProtocolFamily {
        public:
            JazMessagingProtocolFamily();
            virtual ~JazMessagingProtocolFamily();
        };

        class VirtualProtocolFamily : public ProtocolFamily {
        public:
            VirtualProtocolFamily();
            virtual ~VirtualProtocolFamily();
        };

        class ProtocolFamilies {
        public:
            const UndefinedProtocolFamily UNDEFINED_PROTOCOL;
            const OOIProtocolFamily OOI_PROTOCOL;
            const OceanBinaryProtocolFamily OCEAN_BINARY_PROTOCOL;
            const JazMessagingProtocolFamily JAZ_MESSAGING_PROTOCOL;
            const VirtualProtocolFamily VIRTUAL_PROTOCOL;

            ProtocolFamilies();
            ~ProtocolFamilies();
            std::vector<ProtocolFamily *> getAllProtocolFamilies();
        };
    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* PROTOCOLFAMILIES_H */

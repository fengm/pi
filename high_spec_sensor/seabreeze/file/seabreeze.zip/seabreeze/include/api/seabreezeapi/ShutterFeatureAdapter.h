/***************************************************//**
 * @file    ShutterFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze ShutterFeatureInterface instances.
 *
 *******************************************************/

#ifndef SHUTTERFEATUREADAPTER_H
#define SHUTTERFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/shutter/ShutterFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class ShutterFeatureAdapter
                : public FeatureAdapterTemplate<ShutterFeatureInterface> {
        public:
            ShutterFeatureAdapter(ShutterFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~ShutterFeatureAdapter();

            void setShutterOpen(int *errorCode, bool open);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* SHUTTERFEATUREADAPTER_H */

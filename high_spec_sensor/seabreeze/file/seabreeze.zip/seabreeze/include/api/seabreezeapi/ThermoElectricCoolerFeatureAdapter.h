/***************************************************//**
 * @file    ThermoElectricCoolerFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze TECFeatureInterface instances.
 *
 *******************************************************/

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/thermoelectric/ThermoElectricFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class ThermoElectricCoolerFeatureAdapter
                : public FeatureAdapterTemplate<ThermoElectricFeatureInterface> {
        public:
            ThermoElectricCoolerFeatureAdapter(ThermoElectricFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~ThermoElectricCoolerFeatureAdapter();

            /* Thermoelectric cooler functions */
            double readTECTemperature(int *errorCode);
            void setTECTemperature(int *errorCode,
                    double temperature_degrees_celsius);
            void setTECEnable(int *errorCode, bool tecEnable);
            void setTECFanEnable(int *errorCode, bool tecFanEnable);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

/***************************************************//**
 * @file    LightSourceFeatureAdapter.h
 * @date    May 2013
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2013 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze LightSourceFeatureInterface instances.
 *
 *******************************************************/

#ifndef LIGHTSOURCEFEATUREADAPTER_H
#define LIGHTSOURCEFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/light_source/LightSourceFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class LightSourceFeatureAdapter
                : public FeatureAdapterTemplate<LightSourceFeatureInterface> {
        public:
            LightSourceFeatureAdapter(LightSourceFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~LightSourceFeatureAdapter();

            int getLightSourceCount(int *errorCode);

            bool hasLightSourceEnable(int *errorCode, int lightSourceIndex);
            bool isLightSourceEnabled(int *errorCode, int lightSourceIndex);
            void setLightSourceEnable(int *errorCode, int lightSourceIndex,
                    bool enable);

            /* The intensity is normalized over the range [0, 1] where 0 is
             * the minimum programmable intensity and 1 is the maximum
             */
            bool hasVariableIntensity(int *errorCode, int lightSourceIndex);
            double getLightSourceIntensity(int *errorCode, int lightSourceIndex);
            void setLightSourceIntensity(int *errorCode, int lightSourceIndex,
                    double intensity);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* LIGHTSOURCEFEATUREADAPTER_H */

/***************************************************//**
 * @file    ContinuousStrobeFeatureAdapter.h
 * @date    October 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows access to SeaBreeze 
 * ContinuousStrobeFeatureInterface instances.
 *
 *******************************************************/

#ifndef SEABREEZE_API_CONTINUOUS_STROBE_FEATURE_ADAPTER_H
#define SEABREEZE_API_CONTINUOUS_STROBE_FEATURE_ADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/continuous_strobe/ContinuousStrobeFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class ContinuousStrobeFeatureAdapter
                : public FeatureAdapterTemplate<ContinuousStrobeFeatureInterface> {
        public:
            ContinuousStrobeFeatureAdapter(ContinuousStrobeFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~ContinuousStrobeFeatureAdapter();

            void setContinuousStrobePeriodMicroseconds(int *errorCode, unsigned long period_usec);
            void setContinuousStrobeEnable(int *errorCode, bool enable);
        };
    } 
} 

#endif

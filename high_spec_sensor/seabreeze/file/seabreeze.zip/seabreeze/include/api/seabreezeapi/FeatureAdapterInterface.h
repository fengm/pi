/***************************************************//**
 * @file    FeatureAdapterInterface.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This interface allows device features to be treated
 * consistently regardless of the actual capabilities.
 *
 *******************************************************/
#ifndef FEATUREADAPTERINTERFACE_H
#define FEATUREADAPTERINTERFACE_H

#include "common/features/FeatureFamily.h"

namespace seabreeze {
    namespace api {

        class FeatureAdapterInterface {
        public:
            virtual ~FeatureAdapterInterface() = 0;

            /* This gets a semi-unique integer ID for this feature instance */
            virtual long getID() = 0;

            /* Gets the general category of the feature, if any */
            virtual FeatureFamily &getFeatureFamily() = 0;
        };

        /* Default empty destructor for otherwise abstract class */
        inline FeatureAdapterInterface::~FeatureAdapterInterface() { }

    } /* end namespace api */
} /* end namespace seabreeze */


#endif /* FEATUREADAPTERINTERFACE_H */

/***************************************************//**
 * @file    StrayLightCoeffsFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze StrayLightCoeffFeatureInterface instances.
 *
 *******************************************************/

#ifndef STRAYLIGHTCOEFFSFEATUREADAPTER_H
#define STRAYLIGHTCOEFFSFEATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "vendors/OceanOptics/features/stray_light/StrayLightCoeffsFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class StrayLightCoeffsFeatureAdapter
                : public FeatureAdapterTemplate<StrayLightCoeffsFeatureInterface> {
        public:
            StrayLightCoeffsFeatureAdapter(StrayLightCoeffsFeatureInterface *intf,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~StrayLightCoeffsFeatureAdapter();

            int readStrayLightCoeffs(int *errorCode, double *buffer,
                    int bufferLength);
        };

    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* STRAYLIGHTCOEFFSFEATUREADAPTER_H */

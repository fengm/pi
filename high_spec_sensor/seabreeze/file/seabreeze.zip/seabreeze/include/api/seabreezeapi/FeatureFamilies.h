/***************************************************//**
 * @file    FeatureFamilies.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to get references to different kinds
 * of features (e.g. spectrometer, TEC) generically.
 *
 *******************************************************/

#ifndef FEATUREFAMILIES_H
#define FEATUREFAMILIES_H

#include "common/features/FeatureFamily.h"
#include <vector>

namespace seabreeze {
    namespace api {

        class UndefinedFeatureFamily : public FeatureFamily {
        public:
            UndefinedFeatureFamily();
            virtual ~UndefinedFeatureFamily();
        };

        class SerialNumberFeatureFamily : public FeatureFamily {
        public:
            SerialNumberFeatureFamily();
            virtual ~SerialNumberFeatureFamily();
        };

        class SpectrometerFeatureFamily : public FeatureFamily {
        public:
            SpectrometerFeatureFamily();
            virtual ~SpectrometerFeatureFamily();
        };

        class ThermoElectricFeatureFamily : public FeatureFamily {
        public:
            ThermoElectricFeatureFamily();
            virtual ~ThermoElectricFeatureFamily();
        };

        class IrradCalFeatureFamily : public FeatureFamily {
        public:
            IrradCalFeatureFamily();
            virtual ~IrradCalFeatureFamily();
        };

        class EEPROMFeatureFamily : public FeatureFamily {
        public:
            EEPROMFeatureFamily();
            virtual ~EEPROMFeatureFamily();
        };

        class LightSourceFeatureFamily : public FeatureFamily {
        public:
            LightSourceFeatureFamily();
            virtual ~LightSourceFeatureFamily();
        };

        class StrobeLampFeatureFamily : public FeatureFamily {
        public:
            StrobeLampFeatureFamily();
            virtual ~StrobeLampFeatureFamily();
        };

        class ContinuousStrobeFeatureFamily : public FeatureFamily {
        public:
            ContinuousStrobeFeatureFamily();
            virtual ~ContinuousStrobeFeatureFamily();
        };

        class ShutterFeatureFamily : public FeatureFamily {
        public:
            ShutterFeatureFamily();
            virtual ~ShutterFeatureFamily();
        };

        class WaveCalFeatureFamily : public FeatureFamily {
        public:
            WaveCalFeatureFamily();
            virtual ~WaveCalFeatureFamily();
        };

        class NonlinearityCoeffsFeatureFamily : public FeatureFamily {
        public:
            NonlinearityCoeffsFeatureFamily();
            virtual ~NonlinearityCoeffsFeatureFamily();
        };

        class StrayLightCoeffsFeatureFamily : public FeatureFamily {
        public:
            StrayLightCoeffsFeatureFamily();
            virtual ~StrayLightCoeffsFeatureFamily();
        };

        class RawBusAccessFeatureFamily : public FeatureFamily {
        public:
            RawBusAccessFeatureFamily();
            virtual ~RawBusAccessFeatureFamily();
        };

        class FeatureFamilies {
        public:
            const UndefinedFeatureFamily UNDEFINED;
            const SerialNumberFeatureFamily SERIAL_NUMBER;
            const SpectrometerFeatureFamily SPECTROMETER;
            const ThermoElectricFeatureFamily THERMOELECTRIC;
            const IrradCalFeatureFamily IRRAD_CAL;
            const EEPROMFeatureFamily EEPROM;
            const LightSourceFeatureFamily LIGHT_SOURCE;
            const StrobeLampFeatureFamily STROBE_LAMP_ENABLE;
            const ContinuousStrobeFeatureFamily CONTINUOUS_STROBE;
            const ShutterFeatureFamily SHUTTER;
            const WaveCalFeatureFamily WAVELENGTH_CAL;
            const NonlinearityCoeffsFeatureFamily NONLINEARITY_COEFFS;
            const StrayLightCoeffsFeatureFamily STRAY_LIGHT_COEFFS;
            const RawBusAccessFeatureFamily RAW_BUS_ACCESS;

            FeatureFamilies();
            ~FeatureFamilies();
            std::vector<FeatureFamily *> getAllFeatureFamilies();
        };
    } /* end namespace api */
} /* end namespace seabreeze */

#endif /* FEATUREFAMILIES_H */

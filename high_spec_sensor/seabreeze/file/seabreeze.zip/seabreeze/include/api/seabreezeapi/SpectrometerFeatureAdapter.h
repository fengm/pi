/***************************************************//**
 * @file    SpectrometerFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze OOISpectrometerFeature instances.
 *
 *******************************************************/
#ifndef SPECTROMETERFERATUREADAPTER_H
#define SPECTROMETERFERATUREADAPTER_H

#include "api/seabreezeapi/FeatureAdapterTemplate.h"
#include "common/buses/Bus.h"
#include "common/protocols/Protocol.h"
#include "vendors/OceanOptics/features/spectrometer/OOISpectrometerFeatureInterface.h"

namespace seabreeze {
    namespace api {

        class SpectrometerFeatureAdapter : public FeatureAdapterTemplate<OOISpectrometerFeatureInterface> {
        public:
            SpectrometerFeatureAdapter(
                OOISpectrometerFeatureInterface *spec,
                    const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex);
            virtual ~SpectrometerFeatureAdapter();

            /* Spectrometer commands */
            int getUnformattedSpectrum(int *errorCode,
                    unsigned char *buffer, int bufferLength);
            int getFormattedSpectrum(int *errorCode,
                    double* buffer, int bufferLength);
            int getUnformattedSpectrumLength(int *errorCode);
            int getFormattedSpectrumLength(int *errorCode);
            void setTriggerMode(int *errorCode, int mode);
            int getWavelengths(int *errorCode, double *wavelengths, int length);
            int getElectricDarkPixelCount(int *errorCode);
            int getElectricDarkPixelIndices(int *errorCode,
                    int *indices, int length);
            void setIntegrationTimeMicros(int *errorCode,
                    unsigned long integrationTimeMicros);
            long getMinimumIntegrationTimeMicros(int *errorCode);
        };

    } /* end namespace api */
} /* end namespace seabreeze */


#endif /* SPECTROMETERFERATUREADAPTER_H */

/***************************************************//**
 * @file    SeaBreeze.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides some project-wide constants and definitions.
 *
 *******************************************************/

#ifndef SEABREEZE_H
#define SEABREEZE_H

typedef unsigned char byte;

#ifdef WINDOWS
/* Visual studio does not implement declared exception
 * specification but accepts it with a warning.  This
 * suppresses the warning (4290).
 */
#pragma warning( disable : 4290 )
#endif /* WINDOWS */

#endif /* SEABREEZE_H */

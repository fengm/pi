/***************************************************//**
 * @file    UShortVector.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#ifndef SEABREEZE_USHORTVECTOR_H
#define SEABREEZE_USHORTVECTOR_H

#include <vector>
#include "common/SeaBreeze.h"
#include "common/Data.h"

namespace seabreeze {

    class UShortVector : public Data {
    public:
        UShortVector();
        /* Constructor that makes a copy of the given vector for internal use */
        UShortVector(const std::vector<unsigned short> &that);
        UShortVector(unsigned int length);
        virtual ~UShortVector();
        /* Dimensionality of data.  0 for scalar, 1 for vector,
         * 2 for a pair of related vectors (e.g. [X, Y] or matrix),
         * 3 for 3D, etc.
         */
        virtual int getNumberOfDimensions();

        /* Get all of the unit descriptors associated with this Data. */
        virtual std::vector<UnitDescriptor *> *getUnits();

        /* Get the data associated with this instance */
        std::vector<unsigned short> &getUShortVector();

    private:
        std::vector<unsigned short> *data;
    };

} /* end of namespace */

#endif /* SEABREEZE_USHORTVECTOR_H */

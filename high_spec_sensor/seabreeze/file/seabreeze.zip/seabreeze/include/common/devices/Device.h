/***************************************************//**
 * @file    Device.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for all sorts of devices.  A
 * device is really just an aggregation of features
 * with the protocols and buses required to access them.
 * A Device is intended to represent a single discrete
 * piece of equipment that may have several capabilities
 * (features) inside.  The device may communicate to the
 * outside world via seqences of bytes (a protocol) that
 * are transferred across a physical medium (the bus).
 *
 *******************************************************/

#ifndef DEVICE_H
#define DEVICE_H

#include <vector>
#include <string>
#include "common/buses/Bus.h"
#include "common/buses/BusFamily.h"
#include "common/buses/DeviceLocatorInterface.h"
#include "common/features/Feature.h"
#include "common/features/FeatureFamily.h"
#include "common/protocols/Protocol.h"

namespace seabreeze {

    class Device {
    public:
        Device();
        virtual ~Device();
        std::vector<Bus *> &getBuses();
        std::vector<Feature *> &getFeatures();
        std::vector<Protocol *> &getProtocols();
        std::string &getName();

        /* This will allow the driver to probe the device and initialize itself
         * based on what it finds there.  This should be called shortly after
         * open().  The Device instance should use the indicated Bus instance to
         * communicate with the hardware and get everything set up.  It can
         * use any appropriate protocol or protocols that are valid for the Bus.
         */
        virtual bool initialize(const Bus &bus);

        /* Each instance of a device is assumed to be associated with a unique
         * location on a bus.  If the device is connected via multiple buses, then
         * a special DeviceLocator and TransferHelper will have to hide those
         * details.  Otherwise, each connection to the device will be considered
         * independent of all others.
         */
        virtual DeviceLocatorInterface *getLocation();
        virtual void setLocation(const DeviceLocatorInterface &loc);

        virtual int open();

        virtual void close();

        virtual std::vector<Bus *> getBusesByFamily(BusFamily &family);

        virtual seabreeze::ProtocolFamily getSupportedProtocol(
                seabreeze::FeatureFamily family, BusFamily bus) = 0;

        virtual std::vector<Protocol *> getProtocolsByFamily(
                seabreeze::ProtocolFamily &family);

        virtual Bus *getOpenedBus();

    protected:
        std::vector<Bus *> buses;
        std::vector<Feature *> features;
        std::vector<Protocol *> protocols;

        std::string name;

        DeviceLocatorInterface *location;
        Bus *openedBus;
    };

} /* end namespace */

#endif /* DEVICE_H */


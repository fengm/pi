/***************************************************//**
 * @file    UnitDescriptor.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#ifndef SEABREEZE_UNITDESCRIPTOR_H
#define SEABREEZE_UNITDESCRIPTOR_H

namespace seabreeze {

    class UnitDescriptor {
    public:
        UnitDescriptor();
        ~UnitDescriptor();

        /* FIXME: need to define unit property getters */

    };


} /* end of namespace */

#endif /* SEABREEZE_UNITDESCRIPTOR_H */

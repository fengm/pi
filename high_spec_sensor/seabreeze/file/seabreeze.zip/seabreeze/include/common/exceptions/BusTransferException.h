/***************************************************//**
 * @file    BusTransferException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This exception should be used when an error is
 * encountered when trying to read from or write to
 * a bus.
 *
 *******************************************************/

#ifndef BUSTRANSFEREXCEPTION_H
#define BUSTRANSFEREXCEPTION_H

#include "common/exceptions/BusException.h"

namespace seabreeze {

    class BusTransferException : public BusException {
    public:
        BusTransferException(const std::string &error);
    };

}

#endif /* BUSTRANSFEREXCEPTION_H */

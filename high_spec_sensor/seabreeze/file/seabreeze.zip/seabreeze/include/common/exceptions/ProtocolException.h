/***************************************************//**
 * @file    ProtocolException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for a family of exceptions that
 * arise from errors in protocols.  These may be thrown
 * at the protocol layer, and all exceptions thrown at
 * that layer must extend this class so that they can be
 * uniformly handled.
 *
 *******************************************************/

#ifndef PROTOCOLEXCEPTION_H
#define PROTOCOLEXCEPTION_H

#include <stdexcept>
#include <string>

namespace seabreeze {

    class ProtocolException : public std::runtime_error {
    public:
        ProtocolException(const std::string &error);
    };


} /* End of namespace */

#endif /* PROTOCOLEXCEPTION_H */

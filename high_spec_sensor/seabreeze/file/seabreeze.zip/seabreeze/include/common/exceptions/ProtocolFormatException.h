/***************************************************//**
 * @file    ProtocolFormatException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This exception should be used when a protocol message
 * cannot be decoded, fails a checksum, or otherwise is
 * out of spec.  This may indicate that the driver is now
 * out of synch with this code and that measures should be
 * taken to re-establish communications.
 *
 *******************************************************/

#ifndef PROTOCOLFORMATEXCEPTION_H
#define PROTOCOLFORMATEXCEPTION_H

#include "common/exceptions/ProtocolException.h"

namespace seabreeze {

    class ProtocolFormatException : public ProtocolException {
    public:
        ProtocolFormatException(const std::string &error);
    };

}

#endif /* PROTOCOLFORMATEXCEPTION_H */

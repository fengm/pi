/***************************************************//**
 * @file    ProtocolBusMismatchException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This exception should be used when a protocol is
 * specified, but the bus and protocol are not suited to
 * each other (e.g. there is no bus helper for the hints
 * the protocol can provide).
 *
 *******************************************************/

#ifndef PROTOCOLBUSMISMATCHEXCEPTION_H
#define PROTOCOLBUSMISMATCHEXCEPTION_H

#include "common/exceptions/ProtocolException.h"

namespace seabreeze {

    class ProtocolBusMismatchException : public ProtocolException {
    public:
        ProtocolBusMismatchException(const std::string &error);
    };

}

#endif /* PROTOCOLBUSMISMATCHEXCEPTION_H */

/***************************************************//**
 * @file    NumberFormatException.h
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is an exception for use when a string is to be
 * parsed into a number but the string does not contain
 * a recognizable number.
 *
 *******************************************************/

#ifndef NUMBERFORMATEXCEPTION_H
#define NUMBERFORMATEXCEPTION_H

#include <stdexcept>
#include <string>

namespace seabreeze {

    class NumberFormatException : public std::runtime_error {
    public:
        NumberFormatException(const std::string &error);
    };


} /* End of namespace */

#endif /* NUMBERFORMATEXCEPTION_H */

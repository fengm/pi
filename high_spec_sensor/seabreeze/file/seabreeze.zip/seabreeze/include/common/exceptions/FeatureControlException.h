/***************************************************//**
 * @file    FeatureControlException.h
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This exception should be used when an error is
 * encountered when trying to interact with a feature.
 *
 *******************************************************/

#ifndef FEATURECONTROLEXCEPTION_H
#define FEATURECONTROLEXCEPTION_H

#include "common/exceptions/FeatureException.h"

namespace seabreeze {

    class FeatureControlException : public FeatureException {
    public:
        FeatureControlException(const std::string &error);
    };

}

#endif /* FEATURECONTROLEXCEPTION_H */

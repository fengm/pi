/***************************************************//**
 * @file    FeatureProtocolNotFoundException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This exception should be used when a protocol is
 * specified, but no matching implementation of that
 * protocol can be found for a particular feature.
 *
 *******************************************************/

#ifndef FEATUREPROTOCOLNOTFOUNDEXCEPTION_H
#define FEATUREPROTOCOLNOTFOUNDEXCEPTION_H

#include "common/exceptions/FeatureException.h"

namespace seabreeze {

    class FeatureProtocolNotFoundException : public FeatureException {
    public:
        FeatureProtocolNotFoundException(const std::string &error);
    };

}

#endif /* FEATUREPROTOCOLNOTFOUNDEXCEPTION_H */

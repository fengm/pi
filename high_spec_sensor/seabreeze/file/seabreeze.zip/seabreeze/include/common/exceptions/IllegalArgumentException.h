/***************************************************//**
 * @file    IllegalArgumentException.h
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is an exception for use when a value is passed to
 * a method that is not permitted.  This may include
 * specifying a parameter that is out of bounds or of
 * the wrong type.
 *
 *******************************************************/

#ifndef ILLEGALARGUMENTEXCEPTION_H
#define ILLEGALARGUMENTEXCEPTION_H

#include <stdexcept>
#include <string>

namespace seabreeze {

    class IllegalArgumentException : public std::invalid_argument {
    public:
        IllegalArgumentException(const std::string &error);
    };


} /* End of namespace */

#endif /* ILLEGALARGUMENTEXCEPTION_H */

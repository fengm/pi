/***************************************************//**
 * @file    BusException.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for a family of exceptions that
 * arise from errors in bus transfers.  These may be thrown
 * at the bus layer, and all exceptions thrown at
 * that layer must extend this class so that they can be
 * uniformly handled.
 *
 *******************************************************/

#ifndef BUSEXCEPTION_H
#define BUSEXCEPTION_H

#include <stdexcept>

namespace seabreeze {

    class BusException : public std::runtime_error {
    public:
        BusException(const std::string &error);
    };


} /* End of namespace */

#endif /* BUSEXCEPTION_H */

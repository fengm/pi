/***************************************************//**
 * @file    ProtocolHint.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * Hints are used to identify particular characteristics about
 * protocol Transfer objects.  A hint may be used to indicate
 * to a bus some detail it needs about making a transfer, e.g.
 * what endpoint would be appropriate for USB.  Note that the
 * bus (or its helpers) are under no obligation to respect hints.
 *
 *******************************************************/

#ifndef PROTOCOLHINT_H
#define PROTOCOLHINT_H

#include "common/SeaBreeze.h"
#include <string>

namespace seabreeze {

    class ProtocolHint {
    public:
        ProtocolHint(int id, std::string desc);

        /* For derived classes that will fill in their own values
         * and for containers to be able to initialize themselves.
         * This does not set any meaningful values and should not be
         * relied on to create a proper instance.
         */
        ProtocolHint();

        virtual ~ProtocolHint();
        std::string getDescription();
        int getID() const;

        /* Overloading the equality operator so that this can be
         * used as a key for hash_map associations without the actual
         * key objects having to be identical.
         */
        bool operator==(const ProtocolHint &that);

    protected:
        int id;
        std::string description;
    };

} /* end of namespace */

#endif /* PROTOCOLHINT_H */


/***************************************************//**
 * @file    ProtocolFamily.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds
 * protocols (e.g. OOI, OBP) generically.
 *
 *******************************************************/
#ifndef PROTOCOLFAMILY_H
#define PROTOCOLFAMILY_H

#include <string>

namespace seabreeze {
    class ProtocolFamily {
    public:
        virtual ~ProtocolFamily();
        virtual std::string getName();
        virtual bool equals(const ProtocolFamily &that);
        virtual unsigned short getType();

    protected:
        ProtocolFamily(std::string name, unsigned short id);

    private:
        std::string protocolName;
        unsigned short type;
    };
} /* end namespace seabreeze */

#endif /* PROTOCOLFAMILY_H */

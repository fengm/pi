/***************************************************//**
 * @file    Transaction.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * The Transaction class is simply a wrapper
 * around one or more Transfer objects that must
 * be executed in a particular order.  This is
 * provided for convenience.  Some transfers
 * to Ocean Optics spectrometers put the spectrometer
 * into a particular state where it expects another
 * action to be taken, and Transaction objects can
 * be used to ensure that all expected operations occur.
 *
 * Some actions, like requesting a spectrum, do not
 * necessarily require that the next action be a read
 * operation.  Thus, some Transfers that appear to follow
 * a causal chain may not in fact make good Transactions.
 * In this case, reading the status of the device until
 * it reports data ready is a common operation before
 * reading the spectrum.
 *
 * Note that the Transaction class has no notion of buses
 * or protocols, and this is by design.
 *
 *******************************************************/

#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <vector>
#include "common/protocols/Exchange.h"
#include "common/protocols/Transfer.h"
#include "common/buses/TransferHelper.h"
#include "common/protocols/ProtocolHint.h"
#include "common/Data.h"

namespace seabreeze {

    class Transaction : public Exchange {
    public:
        Transaction();
        virtual ~Transaction();
        void addTransfer(Transfer *xfer);

        /* Inherited from Exchange */
        virtual Data *transfer(TransferHelper *helper) throw (ProtocolException);
        virtual const std::vector<ProtocolHint *> &getHints();

    private:
        void updateHints();

        std::vector<Transfer *> transfers;
        std::vector<ProtocolHint *> hints;
    };

} /* end of namespace */

#endif /* TRANSACTION_H */


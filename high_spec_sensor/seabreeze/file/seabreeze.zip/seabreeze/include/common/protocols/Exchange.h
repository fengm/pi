/***************************************************//**
 * @file    Exchange.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is simply an interface that other classes will
 * extend to have a common transfer() and getHints methods
 *
 *******************************************************/

#ifndef EXCHANGE_H
#define EXCHANGE_H

#include <vector>
#include "common/buses/TransferHelper.h"
#include "common/protocols/ProtocolHint.h"
#include "common/Data.h"
#include "common/exceptions/ProtocolException.h"

namespace seabreeze {

    class Exchange {
    public:
        Exchange();
        virtual ~Exchange();
        virtual Data *transfer(TransferHelper *helper) throw (ProtocolException) = 0;
        virtual const std::vector<ProtocolHint *> &getHints() = 0;
    };

} /* end of namespace */

#endif /* EXCHANGE_H */


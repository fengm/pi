/***************************************************//**
 * @file    Protocol.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a simple identifier cookie that will allow two
 * objects to agree on whether they support a given command
 * set (protocol).  Each will hold Protocol objects that they
 * can then compare to see if they agree.  This allows a loose
 * binding between sets of Exchanges (elsewhere called protocols)
 * and buses.
 *
 *******************************************************/

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "common/protocols/ProtocolFamily.h"

namespace seabreeze {

    class Protocol {
    public:
        Protocol(int id);
        /* Copy constructor */
        Protocol(Protocol const &that);
        virtual ~Protocol();
        bool equals(Protocol const &that);

        virtual ProtocolFamily getProtocolFamily() = 0;

    protected:
        /* Protected for derived classes to use. */
        Protocol();
        int id;
    };

} /* end of namespace */

#endif /* PROTOCOL_H */


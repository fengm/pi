/***************************************************//**
 * @file    Transfer.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * The Transfer class captures a simplex
 * data transfer to or from a device.  At this
 * level, there is no notion of a particular bus,
 * just data, length, and direction.
 *
 * The bus aspects are encapsulated in a "helper"
 * object that must be provided when the Transfer
 * is executed.  The helper must provide send() and
 * receive() methods taking a buffer and length
 * only.  All of the details in getting the transfer to
 * or from the other end must be handled by the helper.
 * The helper is expected to be created by some aspect
 * of the driver for the device in question.  It contains
 * information about the connection and the particulars
 * about routing data in and out.
 *
 * Note that the Transfer class is completely orthagonal to any
 * particular protocol.  It is expected that a protocol may be
 * built up as a collection of related Transfer types.
 *
 *******************************************************/

#ifndef TRANSFER_H
#define TRANSFER_H

#include <vector>
#include "common/protocols/Exchange.h"
#include "common/protocols/ProtocolHint.h"
#include "common/Data.h"

typedef unsigned int direction_t;

namespace seabreeze {

    class Transfer : public Exchange {
    public:

        /* Note that the size of the provided buffer and the specified length
         * of the transfer itself do not need to agree.  If the transfer requires
         * more space than the buffer provides, the buffer will be resized.
         * If the buffer is created larger than is needed, only the given length
         * will be sent or received.  This allows for some freedom in buffer
         * management.
         */
        Transfer(std::vector<ProtocolHint *> *hints, std::vector<byte> *buffer,
                direction_t direction, unsigned int length);

        virtual ~Transfer();
        virtual Data *transfer(TransferHelper *helper) throw (ProtocolException);

        virtual const std::vector<ProtocolHint *> &getHints();

        static const direction_t TO_DEVICE;
        static const direction_t FROM_DEVICE;

    protected:
        Transfer();
        void checkBufferSize();

        std::vector<ProtocolHint *> *hints;
        unsigned int length;
        std::vector<byte> *buffer;
        direction_t direction;
    };

} /* end of namespace */

#endif /* TRANSFER_H */


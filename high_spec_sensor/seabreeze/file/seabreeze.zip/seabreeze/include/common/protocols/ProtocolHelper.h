/***************************************************//**
 * @file    ProtocolHelper.h
 * @date    July 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * Feature instances may look up an implementation object
 * that matches a particular Protocol.  All such implementations
 * should in some way derive from ProtocolHelper so that
 * Feature's look up mechanism can return them.  It is
 * expected that each Feature will have a corresponding
 * interface at the Protocol layer; those interface classes
 * should derive from this class, and their implementations
 * will thus extend this as well.
 *
 *******************************************************/

#ifndef PROTOCOLHELPER_H
#define PROTOCOLHELPER_H

#include "common/protocols/Protocol.h"

namespace seabreeze {

    class ProtocolHelper {
    public:
        ProtocolHelper(Protocol *proto);
        virtual ~ProtocolHelper();
        Protocol &getProtocol();

    protected:
        /* Protected for derived classes to use. */
        ProtocolHelper();
        Protocol *protocol;
    };

} /* end of namespace */

#endif /* PROTOCOLHELPER_H */


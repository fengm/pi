/***************************************************//**
 * @file    Data.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a sort of a wrapper class that can encapsulate
 * different kinds of data that may be returned as the
 * result of a protocol transfer.  The idea is that the
 * data being passed back up from the device probably needs
 * to be in some specific form, but we need to be able
 * to convert it to whatever the receiver can use.
 *
 *******************************************************/

#ifndef SEABREEZE_DATA_H
#define SEABREEZE_DATA_H

#include "common/SeaBreeze.h"
#include "common/UnitDescriptor.h"
#include <vector>

namespace seabreeze {

    class Data {
    public:
        Data();
        virtual ~Data();
        /* Dimensionality of data.  0 for scalar, 1 for vector,
         * 2 for a pair of related vectors (e.g. [X, Y] or matrix),
         * 3 for 3D, etc.
         */
        virtual int getNumberOfDimensions();

        /* Get all of the unit descriptors associated with this Data. */
        virtual std::vector<UnitDescriptor *> *getUnits();
    };

} /* end of namespace */

#endif /* DATA_H */

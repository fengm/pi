/***************************************************//**
 * @file    FeatureFamily.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds
 * features (e.g. spectrometer, TEC) generically.
 *
 *******************************************************/
#ifndef FEATUREFAMILY_H
#define FEATUREFAMILY_H

#include <string>

namespace seabreeze {
    class FeatureFamily {
    public:
        FeatureFamily();
        virtual ~FeatureFamily();
        virtual std::string getName();
        virtual bool equals(const FeatureFamily &that);
        virtual unsigned short getType();

    protected:
        FeatureFamily(std::string name, unsigned short id);

    private:
        std::string featureName;
        unsigned short type;
    };
} /* end namespace seabreeze */

#endif /* FEATUREFAMILY_H */

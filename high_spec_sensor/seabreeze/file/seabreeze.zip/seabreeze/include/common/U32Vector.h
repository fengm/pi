/***************************************************//**
 * @file    U32Vector.h
 * @date    September 2013
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2013 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#ifndef SEABREEZE_U32VECTOR_H
#define SEABREEZE_U32VECTOR_H

#include <vector>
#include "common/SeaBreeze.h"
#include "common/Data.h"

/* This class requires a 32-bit integer type.  This will need a little help
 * to know what the target machine is, so this tries to work it out.
 */ 
#ifdef _MSC_VER
/* Visual Studio */
typedef __int32 int32_t;
typedef unsigned __int32 uint32_t;
#else
/* C99 compatible */
#include <stdint.h>
#endif


namespace seabreeze {

    class U32Vector : public Data {
    public:
        U32Vector();
        /* Constructor that makes a copy of the given vector for internal use */
        U32Vector(const std::vector<uint32_t> &that);
        U32Vector(unsigned int length);
        virtual ~U32Vector();
        /* Dimensionality of data.  0 for scalar, 1 for vector,
         * 2 for a pair of related vectors (e.g. [X, Y] or matrix),
         * 3 for 3D, etc.
         */
        virtual int getNumberOfDimensions();

        /* Get all of the unit descriptors associated with this Data. */
        virtual std::vector<UnitDescriptor *> *getUnits();

        /* Get the data associated with this instance */
        std::vector<uint32_t> &getU32Vector();

    private:
        std::vector<uint32_t> *data;
    };

} /* end of namespace */

#endif /* SEABREEZE_U32VECTOR_H */

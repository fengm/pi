/***************************************************//**
 * @file    DeviceLocatorInterface.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * DeviceLocatorInterface provides a base interface for
 * classes that allow the location of a device to be
 * specified in a bus-specific way.  For instance, a
 * USB DeviceLocator might include a device path or
 * index, and a socket DeviceLocator might include an
 * IP address and port number.  This allows
 * devices that cannot be identified by probing to still
 * be found easily.
 *
 *******************************************************/

#ifndef DEVICELOCATORINTERFACE_H
#define DEVICELOCATORINTERFACE_H

#include <string>
#include "common/buses/BusFamily.h"

namespace seabreeze {

    class DeviceLocatorInterface {
    public:
        virtual ~DeviceLocatorInterface() = 0;

        /**
         * Get a unique identifier for this location.  This can be any value
         * as long as it is globally unique.
         */
        virtual unsigned long getUniqueLocation() const = 0;

        /**
         * Determine whether this DeviceLocator refers to the same device
         * as another.
         */
        virtual bool equals(DeviceLocatorInterface &that) = 0;

        /**
         * Get a human-readable string that describes the location
         */
        virtual std::string getDescription() = 0;

        /**
         * Get a description of the type of bus that the device is associated withs
         */
        virtual BusFamily getBusFamily() const = 0;

        /* Get an exact copy of this instance */
        virtual DeviceLocatorInterface *clone() const = 0;
    };

    /* Default implementation for (otherwise) pure virtual destructor */
    inline DeviceLocatorInterface::~DeviceLocatorInterface() {}


} /* end namespace */

#endif /* DEVICELOCATORINTERFACE_H */

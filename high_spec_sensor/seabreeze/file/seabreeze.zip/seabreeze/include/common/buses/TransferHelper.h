/***************************************************//**
 * @file    TransferHelper.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is effectively an interface for wrappers around bus
 * activity.  These wrappers may be selected from a Bus
 * based on certain hints provided by a Protocol or its
 * various Exchanges.  All that this specifies is that a
 * given object must be able to send() and receive() data
 * across its particular (encapsulated) Bus.
 *
 *******************************************************/

#ifndef TRANSFERHELPER_H
#define TRANSFERHELPER_H

#include "common/SeaBreeze.h"
#include "common/exceptions/BusTransferException.h"
#include <vector>

namespace seabreeze {

    class TransferHelper {
    public:
        TransferHelper();
        virtual ~TransferHelper();
        virtual int receive(std::vector<byte> &buffer, unsigned int length)
            throw (BusTransferException) = 0;
        virtual int send(const std::vector<byte> &buffer, unsigned int length) const
            throw (BusTransferException) = 0;
    };

} /* end of namespace */

#endif /* TRANSFERHELPER_H */


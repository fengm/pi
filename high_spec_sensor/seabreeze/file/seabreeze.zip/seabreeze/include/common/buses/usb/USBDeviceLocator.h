/***************************************************//**
 * @file    USBDeviceLocator.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This class encapsulates the information needed to open
 * a device on a USB bus.
 *
 *******************************************************/

#ifndef USBDEVICELOCATOR_H
#define USBDEVICELOCATOR_H

#include "common/buses/DeviceLocatorInterface.h"
#include <string>

namespace seabreeze {

    class USBDeviceLocator : public DeviceLocatorInterface {
    public:
        USBDeviceLocator(unsigned long ID);
        virtual ~USBDeviceLocator();

        /* Inherited from DeviceLocatorInterface */
        virtual unsigned long getUniqueLocation() const;
        virtual bool equals(DeviceLocatorInterface &that);
        virtual std::string getDescription();
        virtual BusFamily getBusFamily() const;
        virtual DeviceLocatorInterface *clone() const;

    private:
        unsigned long deviceID;
    };

} /* end namespace */

#endif /* USBDEVICELOCATOR_H */

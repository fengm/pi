/***************************************************//**
 * @file    BusFamily.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds of buses
 * (e.g. USB, Ethernet, serial) generically.
 *
 *******************************************************/
#ifndef BUSFAMILY_H
#define BUSFAMILY_H

#include <string>

namespace seabreeze {
    class BusFamily {
    public:
        virtual ~BusFamily();
        virtual std::string getName();
        virtual bool equals(const BusFamily &that);

    protected:
        BusFamily(std::string name, int id);

    private:
        std::string busName;
        int type;
    };

} /* end namespace */

#endif /* BUSFAMILY_H */

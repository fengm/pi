/***************************************************//**
 * @file    USBInterface.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is an abstract base class intended to be an interface
 * for USB control objects.  This allows USB devices to
 * be opened generically (just by providing the index of
 * the device on the bus) without any concern for
 * the vendor ID, product ID, or underlying USB implementation.
 *
 *******************************************************/

#ifndef USBINTERFACE_H
#define USBINTERFACE_H

#include "common/buses/Bus.h"
#include "native/usb/NativeUSB.h"
#include "native/usb/USB.h"

namespace seabreeze {

    class USBInterface : public Bus {
    public:
        USBInterface();
        virtual ~USBInterface();
        virtual USB *getUSBDescriptor() const;
        virtual DeviceLocatorInterface *getLocation();
        virtual void setLocation(const DeviceLocatorInterface &location);
        virtual BusFamily getBusFamily() const;
        virtual bool open() = 0;
        virtual void close() = 0;

    protected:
        USB *usb;
        DeviceLocatorInterface *deviceLocator;
    };

} /* end namespace */

#endif /* USBINTERFACE_H */


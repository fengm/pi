/***************************************************//**
 * @file    Bus.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a base class for all sorts of buses.  A bus
 * is a mechanism for transferring a stream of data from one
 * point to another.  The bus does not concern itself with the
 * contents of the data stream.  At most, it may use hints to
 * determine how a particular message will be moved if this
 * is necessary to complete the operation.
 *
 *******************************************************/

#ifndef BUS_H
#define BUS_H

#include "common/protocols/ProtocolHint.h"
#include "common/buses/TransferHelper.h"
#include "common/buses/BusFamily.h"
#include "common/buses/DeviceLocatorInterface.h"

namespace seabreeze {

    class Bus {
    public:
        Bus();
        virtual ~Bus();
        virtual TransferHelper *getHelper(const std::vector<ProtocolHint *> &hints) const = 0;
        virtual BusFamily getBusFamily() const = 0;
        /* Associate this Bus instance with a particular device location.
         * This MUST be done before open or close can be used.
         */
        virtual void setLocation(const DeviceLocatorInterface &location) = 0;
        virtual bool open() = 0;
        virtual void close() = 0;
        virtual DeviceLocatorInterface *getLocation() = 0;
    };

} /* end of namespace */

#endif /* BUS_H */


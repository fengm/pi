/***************************************************//**
 * @file    RS232Interface.h
 * @date    April 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#ifndef RS232INTERFACE_H
#define RS232INTERFACE_H

#include "common/buses/Bus.h"
#include "native/rs232/NativeRS232.h"
#include "native/rs232/RS232.h"

namespace seabreeze {

    class RS232Interface : public Bus {
    public:
        RS232Interface();
        virtual ~RS232Interface();
        virtual RS232 *getRS232Descriptor();
        virtual DeviceLocatorInterface *getLocation();
        virtual void setLocation(const DeviceLocatorInterface &location);
        virtual BusFamily getBusFamily() const;
        virtual TransferHelper *getHelper(const std::vector<ProtocolHint *> &hints) const = 0;
        virtual bool open() = 0;
        virtual void close() = 0;

    protected:
        RS232 *rs232;
        DeviceLocatorInterface *deviceLocator;
    };

} /* end namespace */

#endif /* RS232INTERFACE_H */

/***************************************************//**
 * @file    RS232TransferHelper.h
 * @date    April 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides an abstraction around the RS232 bus.
 * RS232 is pretty simple once the port is opened and
 * configured, so this mostly just takes care of ensuring
 * that all bytes are sent and received as required.
 *
 * This will effectively block on reads and writes until
 * they are complete.  A non-blocking transfer helper
 * could be created to complement this if there was
 * some need, but it is not clear who would be responsible
 * for delayed reads or retransmits.
 *
 *******************************************************/

#ifndef RS232TRANSFERHELPER_H
#define RS232TRANSFERHELPER_H

#include "common/buses/TransferHelper.h"
#include "native/rs232/RS232.h"

namespace seabreeze {

    class RS232TransferHelper : public TransferHelper {
    public:
        RS232TransferHelper(RS232 *rs232Descriptor);
        virtual ~RS232TransferHelper();

        virtual int receive(std::vector<byte> &buffer, unsigned int length)
            throw (BusTransferException);
        virtual int send(const std::vector<byte> &buffer, unsigned int length) const
            throw (BusTransferException);

    protected:
        RS232 *rs232;
    };

} /* end namespace */

#endif /* USBTRANSFERHELPER_H */

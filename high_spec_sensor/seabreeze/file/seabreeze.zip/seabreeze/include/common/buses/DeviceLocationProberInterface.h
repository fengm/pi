/***************************************************//**
 * @file    DeviceLocationProberInterface.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * DeviceLocatorInterface provides a base interface for
 * classes that allow the location of a device to be
 * probed in a bus-specific way.
 *
 *******************************************************/

#ifndef DEVICELOCATIONPROBERINTERFACE_H
#define DEVICELOCATIONPROBERINTERFACE_H

#include <vector>
#include "common/buses/DeviceLocatorInterface.h"

namespace seabreeze {

    class DeviceLocationProberInterface {
    public:
        virtual ~DeviceLocationProberInterface() = 0;

        /* Report how many devices of this type are available */
        virtual std::vector<DeviceLocatorInterface *> *probeDevices() = 0;

    protected:
        DeviceLocationProberInterface();
    };

    /* Default implementation for (otherwise) pure virtual destructor */
    inline DeviceLocationProberInterface::~DeviceLocationProberInterface() {}

} /* end namespace */

#endif /* DEVICELOCATIONPROBERINTERFACE_H */

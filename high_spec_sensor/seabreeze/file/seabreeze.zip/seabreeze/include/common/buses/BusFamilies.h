/***************************************************//**
 * @file    BusFamilies.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to get references to different kinds of buses
 * (e.g. USB, Ethernet, serial) generically.
 *
 *******************************************************/

#ifndef BUSFAMILIES_H
#define BUSFAMILIES_H

#include "common/buses/BusFamily.h"
#include <vector>

namespace seabreeze {

    class USBBusFamily : public BusFamily {
    public:
        USBBusFamily();
        virtual ~USBBusFamily();
    };

    class EthernetBusFamily : public BusFamily {
    public:
        EthernetBusFamily();
        virtual ~EthernetBusFamily();
    };

    class RS232BusFamily : public BusFamily {
    public:
        RS232BusFamily();
        virtual ~RS232BusFamily();
    };

    class BusFamilies {
    public:
        const USBBusFamily USB;
        const EthernetBusFamily ETHERNET;
        const RS232BusFamily RS232;

        BusFamilies();
        ~BusFamilies();
        std::vector<BusFamily *> getAllBusFamilies();
    };

} /* end namespace */

#endif /* BUSFAMILIES_H */

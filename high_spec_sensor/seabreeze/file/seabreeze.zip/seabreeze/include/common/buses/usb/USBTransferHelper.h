/***************************************************//**
 * @file    USBTransferHelper.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a TransferHelper intended for USB communications.
 * Each USBTransferHelper must specify a sending and
 * receiving endpoint, which will tend to vary according to
 * the type of data transfer being conducted.  This adapts
 * the send() and receive() methods required of a TransferHelper
 * according to a particular type of transfer, which may be
 * inferred from a ProtocolHint.
 *
 *******************************************************/

#ifndef USBTRANSFERHELPER_H
#define USBTRANSFERHELPER_H

#include "common/buses/TransferHelper.h"
#include "native/usb/USB.h"

namespace seabreeze {

    class USBTransferHelper : public TransferHelper {
    public:
        USBTransferHelper(USB *usbDescriptor, int sendEndpoint,
                int receiveEndpoint);
        USBTransferHelper(USB *usbDescriptor);
        virtual ~USBTransferHelper();

        virtual int receive(std::vector<byte> &buffer, unsigned int length)
            throw (BusTransferException);
        virtual int send(const std::vector<byte> &buffer, unsigned int length) const
            throw (BusTransferException);

    protected:
        USB *usb;
        int sendEndpoint;
        int receiveEndpoint;
    };

} /* end namespace */

#endif /* USBTRANSFERHELPER_H */


/***************************************************//**
 * @file    RS232DeviceLocator.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This class encapsulates the information needed to open
 * a device on an RS232 bus.
 *
 *******************************************************/

#ifndef RS232DEVICELOCATOR_H
#define RS232DEVICELOCATOR_H

#include "common/buses/DeviceLocatorInterface.h"
#include <string>

namespace seabreeze {

    class RS232DeviceLocator : public DeviceLocatorInterface {
    public:
        RS232DeviceLocator(std::string devicePath, int baudRate);
        virtual ~RS232DeviceLocator();

        std::string &getDevicePath();
        int getBaudRate();

        /* Inherited from DeviceLocatorInterface */
        virtual unsigned long getUniqueLocation() const;
        virtual bool equals(DeviceLocatorInterface &that);
        virtual std::string getDescription();
        virtual BusFamily getBusFamily() const;
        virtual DeviceLocatorInterface *clone() const;

    private:
        void computeLocationHash();
        std::string devicePath;
        int baudRate;
        unsigned long locationHash;
    };

} /* end namespace */

#endif /* RS232DEVICELOCATOR_H */

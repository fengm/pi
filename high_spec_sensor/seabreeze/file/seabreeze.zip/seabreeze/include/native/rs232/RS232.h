/***************************************************//**
 * @file    RS232.h
 * @date    April 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#ifndef RS232_H
#define RS232_H

#include "native/rs232/NativeRS232.h"

namespace seabreeze {

    class RS232 {
    public:
        RS232(const char *devicePath, int baudRate);
        virtual ~RS232();

        bool open();
        bool close();
        int write(void *data, unsigned int length_bytes);
        int read(void *data, unsigned int length_bytes);

        void setVerbose(bool v);
        bool isOpened();

    protected:

        /* These methods are primarily for debugging. */
        void rs232HexDump(void *x, int length, bool out);
        void hexDump(void *x, int length);
        void describeTransfer(int length, bool out);

        void *descriptor;
        bool opened;
        bool verbose;
        char *devicePath;
        int baudRate;
    };

} /* end of namespace */

#endif /* USB_H */

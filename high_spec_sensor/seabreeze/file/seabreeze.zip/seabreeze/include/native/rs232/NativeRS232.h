/***************************************************//**
 * @file    NativeRS232.h
 * @date    April 21, 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 ******************************************************/

#ifndef NATIVERS232_H
#define NATIVERS232_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define OPEN_OK 0
#define NO_DEVICE_FOUND -1

void *RS232Open(char *device, int *errorCode);

int RS232Close(void *handle);

int RS232Write(void *handle, char *data, int numberOfBytes);

int RS232Read(void *handle, char *buffer, int numberOfBytes);

int RS232SetBaudRate(void *handle, int rate);

int RS232ClearInputBuffer(void *handle);

int RS232ClearOutputBuffer(void *handle);

int RS232WaitForWrite(void *handle);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* NATIVERS232_H */

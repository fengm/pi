/***************************************************//**
 * @file    NativeRS232Windows.h
 * @date    April 21, 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 ******************************************************/

#ifndef NATIVERS232WINDOWS_H
#define NATIVERS232WINDOWS_H

#ifndef _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_DEPRECATE
#endif

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <windows.h>
#include <stdio.h>

#ifndef INVALID_HANDLE_VALUE
#define INVALID_HANDLE_VALUE (-1)
#endif

#ifdef __BORLANDC__
#define EXPORTED __declspec(dllexport) __stdcall
#else
#define EXPORTED __declspec(dllexport)
#endif /* __BORLANDC__ */
#define int64 __int64

#endif /* NATIVERS232WINDOWS_H */

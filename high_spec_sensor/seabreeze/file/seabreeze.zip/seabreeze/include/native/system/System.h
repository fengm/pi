/***************************************************//**
 * @file    System.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * The System class provides an abstract interface to
 * certain system calls.
 *
 *******************************************************/
#ifndef SEABREEZE_SYSTEM_H
#define SEABREEZE_SYSTEM_H

namespace seabreeze {

    class System {
    public:
        System();
        virtual ~System();

        static void sleepMilliseconds(unsigned int millis);

    };

} /* end of namespace */

#endif /* SEABREEZE_SYSTEM_H */

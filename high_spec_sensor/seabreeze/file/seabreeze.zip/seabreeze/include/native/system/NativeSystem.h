/***************************************************//**
 * @file    NativeSystem.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This file has declarations for the native C functions
 * needed to access certain non-portable system calls.
 *
 *******************************************************/
#ifndef NATIVE_SYSTEM_H
#define NATIVE_SYSTEM_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Native C prototypes */


void sleepMilliseconds(unsigned int msecs);


/* End of C prototypes */


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* NATIVE_SYSTEM_H */

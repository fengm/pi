/***************************************************//**
 * @file    USBDiscovery.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/
#ifndef USBDISCOVERY_H
#define USBDISCOVERY_H

#include "native/usb/USB.h"
#include <vector>

namespace seabreeze {

    /* Empty declaration of USB to deal with cross-includes */
    class USB;

    class USBDiscovery {
    public:
        USBDiscovery();
        ~USBDiscovery();

        /**
         * Probes the bus for devices of the given VID and PID and returns
         * a vector of identifiers.  Note that these IDs are implementation-
         * specific and are not necessarily portable between platforms.  They
         * are not guaranteed to be constant from one program execution to the
         * next, though they should remain constant from one invocation of this
         * method to the next within one execution if no devices change status.
         */
        std::vector<unsigned long> *probeDevices(int vendorID, int productID);

        /**
         * Given an identifier from probeDevices(), create a USB interface to
         * the device that can be used to open/write/read/close the device.
         */
        USB *createUSBInterface(unsigned long deviceID);
    };

} /* end namespace */

#endif /* USBDISCOVERY_H */

/***************************************************//**
 * @file    WindowsGUID.h
 * @date    June 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides GUID definitions for supported devices.
 * These must match what appears in the .inf file for the
 * devices to be found properly through the WinUSB API.
 *
 *******************************************************/

#pragma once


// {BAD36DAB-A3D2-4a0e-8B2E-DA36202187D4}
DEFINE_GUID(GUID_DEVCLASS_OCEANOPTICS_USB,
0xbad36dab, 0xa3d2, 0x4a0e, 0x8b, 0x2e, 0xda, 0x36, 0x20, 0x21, 0x87, 0xd4);

// {DBBAD306-1786-4f2e-A8AB-340D45F0653F}
DEFINE_GUID(GUID_DEVINTERFACE_OCEANOPTICS_USB,
0xdbbad306, 0x1786, 0x4f2e, 0xa8, 0xab, 0x34, 0xd, 0x45, 0xf0, 0x65, 0x3f);

/***************************************************//**
 * @file    USB.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#ifndef USB_H
#define USB_H

#include "native/usb/USBDiscovery.h"
#include "native/usb/NativeUSB.h"
#include <string>

namespace seabreeze {

    /* Empty declaration of USBDiscovery to deal with cross-includes */
    class USBDiscovery;

    class USB {
    public:
        virtual ~USB();

        bool open();
        bool close();
        int write(int endpoint, void *data, unsigned int length_bytes);
        int read(int endpoint, void *data, unsigned int length_bytes);
        void resetEndpoint(int endpoint);

        static void setVerbose(bool v);

        int getDeviceDescriptor(struct USBDeviceDescriptor *desc);
        int getInterfaceDescriptor(struct USBInterfaceDescriptor *desc);
        /* Get the endpoint descriptor where index is the endpoint index. */
        int getEndpointDescriptor(int index, struct USBEndpointDescriptor *epDesc);
        std::string *getStringDescriptor(int index);
        int getMaxPacketSize();

        bool isOpened();

        /* This allows the USBDiscovery class to access the protected
         * constructor and act as a factory for USB instances.
         */
        friend class USBDiscovery;

    protected:

        /* These methods are primarily for debugging. */
        void usbHexDump(void *x, int length, int endpoint);
        void hexDump(void *x, int length);
        void describeTransfer(int length, int endpoint);
        USB(unsigned long deviceID);

        void *descriptor;
        bool opened;
        static bool verbose;
        unsigned long deviceID;
    };

} /* end of namespace */

#endif /* USB_H */

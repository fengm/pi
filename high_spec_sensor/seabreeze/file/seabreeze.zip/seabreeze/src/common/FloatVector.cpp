/***************************************************//**
 * @file    FloatVector.cpp
 * @date    March 2010
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/FloatVector.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

FloatVector::FloatVector() {
    this->data = new vector<float>();
}

FloatVector::FloatVector(const vector<float> &that) {
    this->data = new vector<float>(that);
}

FloatVector::~FloatVector() {
    delete this->data;
}

int FloatVector::getNumberOfDimensions() {
    return 1;
}

vector<UnitDescriptor *> *FloatVector::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

vector<float> &FloatVector::getFloatVector() {
    return *(this->data);
}

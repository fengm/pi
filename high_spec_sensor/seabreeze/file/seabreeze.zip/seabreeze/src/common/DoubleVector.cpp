/***************************************************//**
 * @file    DoubleVector.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/DoubleVector.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

DoubleVector::DoubleVector() {
    this->data = new vector<double>;
}

DoubleVector::DoubleVector(const vector<double> &that) {
    this->data = new vector<double>(that);
}

DoubleVector::~DoubleVector() {
    delete this->data;
}

int DoubleVector::getNumberOfDimensions() {
    return 1;
}

vector<UnitDescriptor *> *DoubleVector::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

vector<double> &DoubleVector::getDoubleVector() {
    return *(this->data);
}

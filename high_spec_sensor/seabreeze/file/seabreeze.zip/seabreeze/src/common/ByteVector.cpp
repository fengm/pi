/***************************************************//**
 * @file    ByteVector.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/ByteVector.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

ByteVector::ByteVector() {
    this->data = new vector<byte>;
}

ByteVector::ByteVector(const vector<byte> &that) {
    this->data = new vector<byte > (that);
}

ByteVector::~ByteVector() {
    delete this->data;
}

int ByteVector::getNumberOfDimensions() {
    return 1;
}

vector<UnitDescriptor *> *ByteVector::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

vector<byte> &ByteVector::getByteVector() {
    return *(this->data);
}

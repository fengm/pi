/***************************************************//**
 * @file    Data.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/Data.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

Data::Data() {

}

Data::~Data() {

}

int Data::getNumberOfDimensions() {
    /* Derived classes should return something different. */
    return 0;
}

vector<UnitDescriptor *> *Data::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

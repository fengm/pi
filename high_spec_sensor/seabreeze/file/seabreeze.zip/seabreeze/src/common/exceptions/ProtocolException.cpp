/***************************************************//**
 * @file    ProtocolException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for a family of exceptions that
 * arise from errors in protocols.  These may be thrown
 * at the protocol layer, and all exceptions thrown at
 * that layer must extend this class so that they can be
 * uniformly handled.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/ProtocolException.h"

using namespace seabreeze;

ProtocolException::ProtocolException(const std::string &msg) : runtime_error(msg) {

}

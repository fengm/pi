/***************************************************//**
 * @file    FeatureException.cpp
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for a family of exceptions that
 * arise from errors in feature interaction.  These may be thrown
 * at the feature layer, and all exceptions thrown at
 * that layer must extend this class so that they can be
 * uniformly handled.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/FeatureException.h"

using namespace seabreeze;

FeatureException::FeatureException(const std::string &msg) : runtime_error(msg) {

}



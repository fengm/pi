/***************************************************//**
 * @file    FeatureControlException.cpp
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/FeatureControlException.h"

using namespace seabreeze;

FeatureControlException::FeatureControlException(const std::string &msg) : FeatureException(msg) {

}


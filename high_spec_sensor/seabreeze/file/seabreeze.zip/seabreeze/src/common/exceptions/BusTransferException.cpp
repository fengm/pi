/***************************************************//**
 * @file    BusTransferException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/BusTransferException.h"

using namespace seabreeze;

BusTransferException::BusTransferException(const std::string &msg) : BusException(msg) {

}

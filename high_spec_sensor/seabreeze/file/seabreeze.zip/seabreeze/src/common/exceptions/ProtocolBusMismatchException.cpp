/***************************************************//**
 * @file    ProtocolBusMismatchException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/ProtocolBusMismatchException.h"

using namespace seabreeze;

ProtocolBusMismatchException::ProtocolBusMismatchException(const std::string &msg) : ProtocolException(msg) {

}

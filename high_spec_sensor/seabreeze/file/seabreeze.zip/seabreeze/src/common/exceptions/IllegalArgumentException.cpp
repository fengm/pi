/***************************************************//**
 * @file    IllegalArgumentException.cpp
 * @date    March 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is an exception for use when a value is passed to
 * a method that is not permitted.  This may include
 * specifying a parameter that is out of bounds or of
 * the wrong type.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/IllegalArgumentException.h"

using namespace seabreeze;

IllegalArgumentException::IllegalArgumentException(const std::string &msg) : invalid_argument(msg) {

}

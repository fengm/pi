/***************************************************//**
 * @file    ProtocolNotFoundException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/FeatureProtocolNotFoundException.h"

using namespace seabreeze;

FeatureProtocolNotFoundException::FeatureProtocolNotFoundException(const std::string &msg) : FeatureException(msg) {

}

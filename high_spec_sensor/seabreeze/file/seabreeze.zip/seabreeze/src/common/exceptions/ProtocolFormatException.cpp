/***************************************************//**
 * @file    ProtocolFormatException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/ProtocolFormatException.h"

using namespace seabreeze;

ProtocolFormatException::ProtocolFormatException(const std::string &msg) : ProtocolException(msg) {

}


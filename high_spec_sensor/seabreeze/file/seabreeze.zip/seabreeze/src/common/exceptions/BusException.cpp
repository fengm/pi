/***************************************************//**
 * @file    BusException.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a base class for a family of exceptions that
 * arise from errors in bus transfers.  These may be thrown
 * at the bus layer, and all exceptions thrown at
 * that layer must extend this class so that they can be
 * uniformly handled.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/exceptions/BusException.h"

using namespace seabreeze;

BusException::BusException(const std::string &msg) : runtime_error(msg) {

}


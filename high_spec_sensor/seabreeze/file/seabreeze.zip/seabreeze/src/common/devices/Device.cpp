/***************************************************//**
 * @file    Device.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/devices/Device.h"

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif

using namespace std;
using namespace seabreeze;

Device::Device() {
    this->openedBus = NULL;
    this->location = NULL;
}

Device::~Device() {
    vector<Bus *>::iterator bIter;
    vector<Feature *>::iterator fIter;
    vector<Protocol *>::iterator pIter;

    for(fIter = this->features.begin(); fIter != this->features.end(); fIter++) {
        delete *fIter;
    }

    for(pIter = this->protocols.begin(); pIter != this->protocols.end(); pIter++) {
        delete *pIter;
    }

    for(bIter = this->buses.begin(); bIter != this->buses.end(); bIter++) {
        delete *bIter;
    }

    if(NULL != this->location) {
        delete this->location;
    }
}

vector<Bus *> &Device::getBuses() {
    return (this->buses);
}

vector<Feature *> &Device::getFeatures() {
    return (this->features);
}

vector<Protocol *> &Device::getProtocols() {
    return (this->protocols);
}

string &Device::getName() {
    return (this->name);
}


DeviceLocatorInterface *Device::getLocation() {
    return this->location;
}

void Device::setLocation(const DeviceLocatorInterface &loc) {
    if(NULL != this->location) {
        delete this->location;
    }

    this->location = loc.clone();
}

bool Device::initialize(const Bus &bus) {

    /* This function can be overridden to probe the hardware and determine
     * what features are available before initializing them.
     */
    vector<Feature *>::iterator fIter;

    for(fIter = this->features.begin(); fIter != this->features.end(); fIter++) {
        try {
            ProtocolFamily protocolFamily = getSupportedProtocol(
                (*fIter)->getFeatureFamily(), bus.getBusFamily());
            vector<Protocol *> protocols = getProtocolsByFamily(protocolFamily);
            if(protocols.size() < 1) {
                /* No supported protocol for this feature on the given bus. */
                continue;
            }
            (*fIter)->initialize(*(protocols[0]), bus);
        } catch (FeatureException &fe) {
            /* This ought to remove the feature if it cannot be accessed */
        }
    }

    return true;
}

int Device::open() {
    if(NULL == this->location) {
        /* Cannot open without a valid location specified */
        return -1;
    }

    /* Look up the bus based on the location type, then push the locator
     * to the bus, open the bus, and store it in the openedBus pointer
     */
    BusFamily targetFamily = location->getBusFamily();
    vector<Bus *> buses = getBusesByFamily(targetFamily);
    if(buses.size() > 0) {
        Bus *bus = buses[0];
        try {
            bool success = false;
            bus->setLocation(*(this->location));
            success = bus->open();
            if(true == success) {
                this->openedBus = bus;
                return 0;
            }
            return -4;
        } catch (runtime_error &re) {
            /* Probably a bad location for this bus */
            return -3;
        }
    } else {
        /* Bus not found. */
        return -2;
    }
}

void Device::close() {
    if(NULL == this->openedBus) {
        return;
    }

    this->openedBus->close();

    this->openedBus = NULL;
}

Bus *Device::getOpenedBus() {
    return this->openedBus;
}

vector<Bus *> Device::getBusesByFamily(BusFamily &family) {
    vector<Bus *>::iterator busIter;
    vector<Bus *> retval;
    for(busIter = this->buses.begin(); busIter != this->buses.end(); busIter++) {
        BusFamily thatFamily = (*busIter)->getBusFamily();
        if(thatFamily.equals(family)) {
            retval.push_back(*busIter);
        }
    }
    return retval;
}

vector<Protocol *> Device::getProtocolsByFamily(ProtocolFamily &family) {
    vector<Protocol *>::iterator protoIter;
    vector<Protocol *> retval;
    for(protoIter = this->protocols.begin(); protoIter != this->protocols.end(); protoIter++) {
        ProtocolFamily thatFamily = (*protoIter)->getProtocolFamily();
        if(thatFamily.equals(family)) {
            retval.push_back(*protoIter);
        }
    }
    return retval;
}

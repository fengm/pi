/***************************************************//**
 * @file    UnitDescriptor.h
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *
 *******************************************************/

#include "common/globals.h"
#include "common/UnitDescriptor.h"

using namespace seabreeze;

UnitDescriptor::UnitDescriptor() {

}

UnitDescriptor::~UnitDescriptor() {

}

/***************************************************//**
 * @file    UShortVector.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/UShortVector.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

UShortVector::UShortVector() {
    this->data = new vector<unsigned short>;
}

UShortVector::UShortVector(const vector<unsigned short> &that) {
    this->data = new vector<unsigned short>(that);
}

UShortVector::UShortVector(unsigned int length) {
    this->data = new vector<unsigned short>(length);
}

UShortVector::~UShortVector() {
    delete this->data;
}

int UShortVector::getNumberOfDimensions() {
    return 1;
}

vector<UnitDescriptor *> *UShortVector::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

vector<unsigned short> &UShortVector::getUShortVector() {
    return *(this->data);
}

/***************************************************//**
 * @file    U32Vector.cpp
 * @date    September 2013
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2013 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/U32Vector.h"
#include <string.h>

using namespace seabreeze;
using namespace std;

U32Vector::U32Vector() {
    this->data = new vector<uint32_t>;
}

U32Vector::U32Vector(const vector<uint32_t> &that) {
    this->data = new vector<uint32_t>(that);
}

U32Vector::U32Vector(unsigned int length) {
    this->data = new vector<uint32_t>(length);
}

U32Vector::~U32Vector() {
    delete this->data;
}

int U32Vector::getNumberOfDimensions() {
    return 1;
}

vector<UnitDescriptor *> *U32Vector::getUnits() {
    /* This base class represents null data -- derived classes
     * must do something more interesting here.
     */
    return NULL;
}

vector<uint32_t> &U32Vector::getU32Vector() {
    return *(this->data);
}

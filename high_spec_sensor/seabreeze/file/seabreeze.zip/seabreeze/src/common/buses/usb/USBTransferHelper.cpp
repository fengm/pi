/***************************************************//**
 * @file    USBTransferHelper.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/usb/USBTransferHelper.h"
#include <string>

using namespace seabreeze;
using namespace std;

USBTransferHelper::USBTransferHelper(USB *usbDescriptor, int sendEndpoint,
        int receiveEndpoint) : TransferHelper() {
    this->usb = usbDescriptor;
    this->sendEndpoint = sendEndpoint;
    this->receiveEndpoint = receiveEndpoint;
}

USBTransferHelper::USBTransferHelper(USB *usbDescriptor) : TransferHelper() {
    this->usb = usbDescriptor;
}

USBTransferHelper::~USBTransferHelper() {

}

int USBTransferHelper::receive(vector<byte> &buffer, unsigned int length)
        throw (BusTransferException) {
    int retval = 0;

    retval = this->usb->read(this->receiveEndpoint, (void *)&(buffer[0]), length);

    if((0 == retval && length > 0) || (retval < 0)) {
        string error("Failed to read any data from USB.");
        throw BusTransferException(error);
    }

    return retval;
}

int USBTransferHelper::send(const vector<byte> &buffer, unsigned int length) const
        throw (BusTransferException) {
    int retval = 0;

    retval = this->usb->write(this->sendEndpoint, (void *)&(buffer[0]), length);

    if((0 == retval && length > 0) || (retval < 0)) {
        string error("Failed to write any data to USB.");
        throw BusTransferException(error);
    }

    return retval;
}


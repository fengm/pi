/***************************************************//**
 * @file    DeviceLocationProberInterface.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * DeviceLocatorInterface provides a base interface for
 * classes that allow the location of a device to be
 * probed in a bus-specific way.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/DeviceLocationProberInterface.h"

using namespace seabreeze;

DeviceLocationProberInterface::DeviceLocationProberInterface() {

}


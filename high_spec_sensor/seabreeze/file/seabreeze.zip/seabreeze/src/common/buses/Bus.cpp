/***************************************************//**
 * @file    Bus.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/Bus.h"

using namespace seabreeze;

Bus::Bus() {

}

Bus::~Bus() {

}


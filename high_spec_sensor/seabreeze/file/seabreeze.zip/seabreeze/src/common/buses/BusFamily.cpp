/***************************************************//**
 * @file    BusFamily.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds of buses
 * (e.g. USB, Ethernet, serial) generically.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/BusFamily.h"

using namespace seabreeze;
using namespace std;

BusFamily::BusFamily(string name, int id) {
    this->busName = name;
    this->type = id;
}

BusFamily::~BusFamily() {

}

string BusFamily::getName() {
    return this->busName;
}

bool BusFamily::equals(const BusFamily &that) {
    return this->type == that.type;
}


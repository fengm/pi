/***************************************************//**
 * @file    RS232DeviceLocator.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This class encapsulates the information needed to open
 * a device on an RS232 bus.
 *
 *******************************************************/

#include "common/globals.h"
#include <stdio.h>
#include "common/buses/rs232/RS232DeviceLocator.h"
#include "common/buses/BusFamilies.h"

#ifdef WINDOWS
#define snprintf _snprintf
#endif

using namespace seabreeze;
using namespace std;

seabreeze::RS232DeviceLocator::RS232DeviceLocator(string path, int baud) {
    this->devicePath = path;
    this->baudRate = baud;
    computeLocationHash();
}

seabreeze::RS232DeviceLocator::~RS232DeviceLocator() {

}

string &seabreeze::RS232DeviceLocator::getDevicePath() {
    return this->devicePath;
}

int seabreeze::RS232DeviceLocator::getBaudRate() {
    return this->baudRate;
}

unsigned long seabreeze::RS232DeviceLocator::getUniqueLocation() const {
    return this->locationHash;
}

void seabreeze::RS232DeviceLocator::computeLocationHash() {
    /* Iterate over the devicePath and compute a sort of hash */
    unsigned long hash = 1;
    string::iterator iter;

    /* Incorporate the baud rate as part of the value */
    hash = 2129 * hash + this->baudRate;

    for(iter = this->devicePath.begin(); iter != this->devicePath.end(); iter++) {
        /* Overflow here does not cause any problems. */
        hash = 31 * hash + (*iter);
    }

    this->locationHash = hash;
}

bool seabreeze::RS232DeviceLocator::equals(DeviceLocatorInterface &that) {
    RS232DeviceLocator *loc;

    loc = dynamic_cast<RS232DeviceLocator *>(&that);
    if(NULL == loc) {
        return false;
    }

    if(loc->getUniqueLocation() != this->getUniqueLocation()) {
        return false;
    }

    BusFamily thisBusFamily = this->getBusFamily();
    BusFamily thatBusFamily = loc->getBusFamily();
    if(false == thisBusFamily.equals(thatBusFamily)) {
        return false;
    }

    return true;
}

string seabreeze::RS232DeviceLocator::getDescription() {
    char buffer[80];
    /* Produce a string in the following format: path@baud */
    snprintf(buffer, 79, "%s@%d", this->devicePath.c_str(), this->baudRate);
    string retval(buffer);
    return retval;
}

BusFamily seabreeze::RS232DeviceLocator::getBusFamily() const {
    RS232BusFamily family;
    return family;
}

DeviceLocatorInterface *seabreeze::RS232DeviceLocator::clone() const {
    RS232DeviceLocator *retval = new RS232DeviceLocator(
            this->devicePath, this->baudRate);

    return retval;
}

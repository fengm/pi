/***************************************************//**
 * @file    RS232TransferHelper.cpp
 * @date    April 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/rs232/RS232TransferHelper.h"
#include "native/system/System.h"
#include <string>

using namespace seabreeze;
using namespace std;

RS232TransferHelper::RS232TransferHelper(RS232 *rs232Descriptor) : TransferHelper() {
    this->rs232 = rs232Descriptor;
}

RS232TransferHelper::~RS232TransferHelper() {

}

int RS232TransferHelper::receive(vector<byte> &buffer, unsigned int length)
        throw (BusTransferException) {
    int retval = 0;
    unsigned int bytesRead = 0;

    while(bytesRead < length) {
        retval = this->rs232->read((void *)&(buffer[bytesRead]), length - bytesRead);
        if(retval < 0) {
            string error("Failed to read any data from RS232.");
            throw BusTransferException(error);
        } else if(retval != 0) {
            bytesRead += retval;
        } else {
            /* Not enough data available to satisfy the request.  Wait for more
             * data to arrive.
             */
            System::sleepMilliseconds(10);
        }
    }

    return bytesRead;
}

int RS232TransferHelper::send(const vector<byte> &buffer, unsigned int length) const
        throw (BusTransferException) {
    int retval = 0;
    unsigned int bytesWritten = 0;

    while(bytesWritten < length) {
        retval = this->rs232->write((void *)&(buffer[bytesWritten]), length - bytesWritten);
        if(retval < 0) {
            string error("Failed to write any data to RS232.");
            throw BusTransferException(error);
        } else if(retval != 0) {
            bytesWritten += retval;
        } else {
            /* Output buffer is probably full.  Wait for some of the bytes to
             * be transferred before trying again.
             */
            System::sleepMilliseconds(10);
        }
    }

    return bytesWritten;
}


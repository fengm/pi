/***************************************************//**
 * @file    RS232Interface.cpp
 * @date    April 2011
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/rs232/RS232Interface.h"
#include "common/buses/BusFamilies.h"

using namespace seabreeze;

RS232Interface::RS232Interface() {
    this->deviceLocator = NULL;
}

RS232Interface::~RS232Interface() {
    if(NULL != this->deviceLocator) {
        delete this->deviceLocator;
    }
}

RS232 *RS232Interface::getRS232Descriptor() {
    return this->rs232;
}


DeviceLocatorInterface *RS232Interface::getLocation() {
    return this->deviceLocator;
}

void RS232Interface::setLocation(const DeviceLocatorInterface &location) {
    if(NULL != this->deviceLocator) {
        delete this->deviceLocator;
    }

    this->deviceLocator = location.clone();
}

BusFamily RS232Interface::getBusFamily() const {
    RS232BusFamily family;
    return family;
}


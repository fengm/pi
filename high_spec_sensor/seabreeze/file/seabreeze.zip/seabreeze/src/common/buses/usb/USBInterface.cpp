/***************************************************//**
 * @file    USBInterface.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/buses/usb/USBInterface.h"
#include "common/buses/BusFamilies.h"

using namespace seabreeze;

USBInterface::USBInterface() {
    this->deviceLocator = NULL;
}

USBInterface::~USBInterface() {
    if(NULL != this->deviceLocator) {
        delete this->deviceLocator;
    }
}

USB *USBInterface::getUSBDescriptor() const {
    return this->usb;
}

DeviceLocatorInterface *USBInterface::getLocation() {
    return this->deviceLocator;
}

void USBInterface::setLocation(const DeviceLocatorInterface &location) {
    if(NULL != this->deviceLocator) {
        delete this->deviceLocator;
    }

    this->deviceLocator = location.clone();
}

BusFamily USBInterface::getBusFamily() const {
    USBBusFamily family;
    return family;
}




/***************************************************//**
 * @file    Transfer.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/Transfer.h"
#include "common/ByteVector.h"
#include <string>

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif

using namespace seabreeze;
using namespace std;

const direction_t Transfer::TO_DEVICE = 1;
const direction_t Transfer::FROM_DEVICE = 2;

Transfer::Transfer(vector<ProtocolHint *> *hints, vector<byte> *buffer,
        direction_t direction, unsigned int length) {
    this->hints = hints;
    this->buffer = buffer;
    this->direction = direction;
    this->length = length;

    checkBufferSize();
}

/* Protected default constructor; assumes that subclass will fill
 * in the values required by the public constructor.  Since these are
 * complex types which probably have to be declared and populated before
 * they can be used, they are not really suitable for the initializer list.
 */
Transfer::Transfer() {
    this->buffer = new vector<byte>;
    this->hints = new vector<ProtocolHint *>;
    this->length = 0;

    checkBufferSize();
}

Transfer::~Transfer() {
    vector<ProtocolHint *>::iterator iter;
    for(iter = this->hints->begin(); iter != this->hints->end(); iter++) {
        delete *iter;
    }

    delete this->buffer;
    delete this->hints;
}

Data *Transfer::transfer(TransferHelper *helper) throw (ProtocolException) {
    int flag = 0;

    /* Execute the actual movement of the data in this object's buffer
     * across the bus represented by the given TransferHelper.
     */
    if(Transfer::TO_DEVICE == this->direction) {
        try {
            flag = helper->send(*(this->buffer), this->length);
            if(((unsigned int)flag) != this->length) {
                /* FIXME: retry, throw exception, something here */
            }
        } catch (BusException &be) {
            string error("Failed to write to bus.");
            /* FIXME: previous exception should probably be bundled up into the new exception */
            /* FIXME: there is probably a more descriptive type for this than ProtocolException */
            throw ProtocolException(error);
        }
        return NULL;
    } else if(Transfer::FROM_DEVICE == this->direction) {
        try {
            flag = helper->receive(*(this->buffer), this->length);
            if(((unsigned int)flag) != this->length) {
                /* FIXME: retry, throw exception, something here */
            }
        } catch (BusException &be) {
            string error("Failed to write to bus.");
            /* FIXME: previous exception should probably be bundled up into the new exception */
            /* FIXME: there is probably a more descriptive type for this than ProtocolException */
            throw ProtocolException(error);
        }

        /* A copy is made of the data before it is sent out for two
         * reasons.  First, this provides safety from the recipient
         * trying to delete it.  Second, it will make it easier for this
         * to be thread-safe later (though anything that touches the
         * buffer internal to this instance will need to be synchronized
         * with other accesses, especially where a derived class calls this
         * method then expects the buffer to be filled in with
         * something useful).  Yes, this incurs overhead, but not much.
         */
        ByteVector *retval = new ByteVector(*(this->buffer));
        return retval;
    } else {
        string error("Invalid transfer direction specified.");
        /* FIXME: there is probably a more descriptive type for this than ProtocolException */
        throw ProtocolException(error);
    }
    return NULL;
}

const vector<ProtocolHint *> &Transfer::getHints() {
    return *(this->hints);
}

void Transfer::checkBufferSize() {
    if(this->buffer->size() < this->length) {
        this->buffer->resize(this->length);
    }
}


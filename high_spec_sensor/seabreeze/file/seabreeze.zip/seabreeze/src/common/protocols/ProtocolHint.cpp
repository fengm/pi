/***************************************************//**
 * @file    ProtocolHint.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/ProtocolHint.h"

using namespace seabreeze;
using namespace std;

ProtocolHint::ProtocolHint(int id, string desc) {
    this->id = id;
    this->description = desc;
}

ProtocolHint::ProtocolHint() {

}

ProtocolHint::~ProtocolHint() {

}

string ProtocolHint::getDescription() {
    return this->description;
}

int ProtocolHint::getID() const {
    return this->id;
}

bool ProtocolHint::operator==(const ProtocolHint &that) {
    return (this->id == that.id);
}

/***************************************************//**
 * @file    Protocol.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/Protocol.h"

using namespace seabreeze;

Protocol::Protocol(int id) {
    this->id = id;
}

Protocol::Protocol(Protocol const &that) {
    this->id = that.id;
}

Protocol::~Protocol() {

}

/* Protected constructor */
Protocol::Protocol() {

}

bool Protocol::equals(Protocol const &that) {
    /* FIXME: should this do any type comparison? */
    return (this->id == that.id);
}


/***************************************************//**
 * @file    ProtocolFamily.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds
 * features (e.g. spectrometer, TEC) generically.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/ProtocolFamily.h"

using namespace seabreeze;
using namespace std;

ProtocolFamily::ProtocolFamily(string name, unsigned short id) {
    this->protocolName = name;
    this->type = id;
}

ProtocolFamily::~ProtocolFamily() {

}

string ProtocolFamily::getName() {
    return this->protocolName;
}

bool ProtocolFamily::equals(const ProtocolFamily &that) {
    return this->type == that.type;
}

unsigned short ProtocolFamily::getType() {
    return this->type;
}


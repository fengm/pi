/***************************************************//**
 * @file    ProtocolHelper.cpp
 * @date    July 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/ProtocolHelper.h"

using namespace seabreeze;

ProtocolHelper::ProtocolHelper(Protocol *proto) {
    this->protocol = proto;
}

ProtocolHelper::~ProtocolHelper() {
    delete(this->protocol);
}

/* Protected constructor */
ProtocolHelper::ProtocolHelper() {

}

Protocol &ProtocolHelper::getProtocol() {
    return *(this->protocol);
}

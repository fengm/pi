/***************************************************//**
 * @file    Exchange.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/Exchange.h"

using namespace seabreeze;

Exchange::Exchange() {

}

Exchange::~Exchange() {

}


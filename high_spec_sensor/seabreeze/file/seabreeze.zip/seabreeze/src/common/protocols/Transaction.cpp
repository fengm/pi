/***************************************************//**
 * @file    Transaction.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/protocols/Transaction.h"

using namespace seabreeze;
using namespace std;

Transaction::Transaction() {

}

Transaction::~Transaction() {
    vector<Transfer *>::iterator iter;
    for(iter = this->transfers.begin(); iter != this->transfers.end(); iter++) {
        delete (*iter);
    }
}

void Transaction::addTransfer(Transfer *xfer) {
    /* Append the transfer to the current queue of transfers. */
    this->transfers.push_back(xfer);

    updateHints();
}

Data *Transaction::transfer(TransferHelper *helper) throw (ProtocolException) {
    Data *retval = NULL;
    vector<Transfer *>::iterator iter = this->transfers.begin();
    /* Iterate over all stored transfers and delegate to the helper to
     * move the data.
     */
    for(iter = this->transfers.begin(); iter != transfers.end(); iter++) {
        if(NULL != retval) {
            /* Get rid of any objects returned from any but the last transfer. */
            delete retval;
            retval = NULL;
        }
        /* Note that this may throw a ProtocolException which will not be caught here. */
        retval = (*iter)->transfer(helper);
    }
    /* This has the effect of returning the result of the last transfer. */
    return retval;

}

const vector<ProtocolHint *> &Transaction::getHints() {
    return this->hints;
}

void Transaction::updateHints() {
    vector<Transfer *>::iterator iter;
    vector<ProtocolHint *>::iterator hintIter;

    this->hints.resize(0);

    /* Iterate over all stored transfers and gather up their hints.
     */
    for(iter = this->transfers.begin(); iter != this->transfers.end(); iter++) {
        vector<ProtocolHint *> h = (*iter)->getHints();
        for(hintIter = h.begin(); hintIter != h.end(); hintIter++) {
            this->hints.push_back(*hintIter);
        }
    }
}


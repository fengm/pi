/***************************************************//**
 * @file    FeatureFamily.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This provides a way to describe different kinds
 * features (e.g. spectrometer, TEC) generically.
 *
 *******************************************************/

#include "common/globals.h"
#include "common/features/FeatureFamily.h"

using namespace seabreeze;
using namespace std;

FeatureFamily::FeatureFamily() {
    this->featureName = "Undefined";
    this->type = 0;
}

FeatureFamily::FeatureFamily(string name, unsigned short id) {
    this->featureName = name;
    this->type = id;
}

FeatureFamily::~FeatureFamily() {

}

string FeatureFamily::getName() {
    return this->featureName;
}

bool FeatureFamily::equals(const FeatureFamily &that) {
    return this->type == that.type;
}

unsigned short FeatureFamily::getType() {
    return this->type;
}


/***************************************************//**
 * @file    Feature.cpp
 * @date    February 2009
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

#include "common/globals.h"
#include "common/features/Feature.h"

using namespace seabreeze;
using namespace std;

Feature::Feature() {

}

Feature::~Feature() {

    vector<ProtocolHelper *>::iterator iter;

    for(iter = this->protocols.begin(); iter != this->protocols.end(); iter++) {
        delete (*iter);
    }
}

bool Feature::initialize(const Protocol &protocol, const Bus &bus)
            throw (FeatureException) {
    /* Override this to initialize device, and/or return a different status */
    return true;
}

ProtocolHelper *Feature::lookupProtocolImpl(const Protocol &protocol)
        throw (FeatureProtocolNotFoundException) {

    vector<ProtocolHelper *>::iterator iter;
    ProtocolHelper *retval = NULL;

    for(iter = this->protocols.begin(); iter != this->protocols.end(); iter++) {
        if((*iter)->getProtocol().equals(protocol)) {
            retval = *iter;
            break;
        }
    }

    if(NULL == retval) {
        string error("Could not find matching protocol implementation.");
        throw FeatureProtocolNotFoundException(error);
    }

    return retval;
}

/***************************************************//**
 * @file    USBDiscovery.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 *******************************************************/

/* Constants */
#define __MAX_USB_DEVICES   127

#include "common/globals.h"
#include "native/usb/USBDiscovery.h"
#include <stdlib.h>

using namespace seabreeze;
using namespace std;

USBDiscovery::USBDiscovery() {

}

USBDiscovery::~USBDiscovery() {

}

vector<unsigned long> *USBDiscovery::probeDevices(int vendorID, int productID) {
    int deviceCount;
    unsigned long *deviceList;
    vector<unsigned long> *retval;
    int i;

    deviceList = (unsigned long *)calloc(__MAX_USB_DEVICES, sizeof(unsigned long));

    deviceCount = USBProbeDevices(vendorID, productID, deviceList,
        __MAX_USB_DEVICES);

    if(deviceCount < 0) {
        /* This masks an error, but the effect is to return an empty vector */
        deviceCount = 0;
    }

    retval = new vector<unsigned long>(deviceCount);
    vector<unsigned long>::iterator iter;
    for(i = 0, iter = retval->begin(); i < deviceCount && iter != retval->end(); i++, iter++) {
        *iter = deviceList[i];
    }

    free(deviceList);

    return retval;
}

USB *USBDiscovery::createUSBInterface(unsigned long deviceID) {
    /* Create a USB instance with the given deviceID.  This constructor for
     * USB is protected, so this class uses a friend relationship to get
     * access.
     */
    USB *retval = new USB(deviceID);

    return retval;
}

/***************************************************//**
 * @file    System.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * The System class provides an abstract interface to
 * certain system calls.
 *
 *******************************************************/

#include "common/globals.h"
#include "native/system/System.h"
#include "native/system/NativeSystem.h"

using namespace seabreeze;

/* Function definitions */
System::System() {

}

System::~System() {

}

void System::sleepMilliseconds(unsigned int millis) {
    /* This delegates to the native C function in the default namespace.
     * The :: prefix is required to prevent this from simply calling
     * the System::sleepMilliseconds() function recursively.
     */
    ::sleepMilliseconds(millis);
}

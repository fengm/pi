/***************************************************//**
 * @file    SerialNumberFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze SerialNumberFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/SerialNumberFeatureAdapter.h"
#include <string.h> /* for memcpy */
#include <string>   

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;

SerialNumberFeatureAdapter::SerialNumberFeatureAdapter(
        SerialNumberFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<SerialNumberFeatureInterface>(intf, f, p, b, instanceIndex) {

    /* Nothing else to do here, the initialization list takes care of it */
}

SerialNumberFeatureAdapter::~SerialNumberFeatureAdapter() {
    /* This is just a wrapper around existing instances -- nothing to delete */
}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
int SerialNumberFeatureAdapter::getSerialNumber(int *errorCode,
            char *buffer, int buffer_length) {

    string *serialNumber;

    try {
        serialNumber = this->feature->readSerialNumber(
            *this->protocol, *this->bus);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }

    if(NULL == serialNumber) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }

    memset(buffer, (int)0, buffer_length);

    string::iterator iter;
    int i = 0;
    for(iter = serialNumber->begin(); iter != serialNumber->end() && i < buffer_length; iter++, i++) {
        buffer[i] = *iter;
    }
    delete serialNumber;

    SET_ERROR_CODE(ERROR_SUCCESS);
    return i;
}


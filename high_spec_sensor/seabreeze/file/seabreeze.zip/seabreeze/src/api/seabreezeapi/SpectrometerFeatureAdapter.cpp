/***************************************************//**
 * @file    SpectrometerFeatureAdapter.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze OOISpectrometerFeature instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include <string>       
#include <string.h>     /* for memcpy() */
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/SpectrometerFeatureAdapter.h"
#include "common/exceptions/IllegalArgumentException.h"

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;

SpectrometerFeatureAdapter::SpectrometerFeatureAdapter(
        OOISpectrometerFeatureInterface *spec, const FeatureFamily &f,
        seabreeze::Protocol *p, seabreeze::Bus *b, unsigned short instanceID)
            : FeatureAdapterTemplate<OOISpectrometerFeatureInterface>(spec,
                family, p, b, instanceID) {

}

SpectrometerFeatureAdapter::~SpectrometerFeatureAdapter() {
    /* This is just a wrapper around pointers to instances.  This is not
     * responsible for destroying anything.
     */
}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
int SpectrometerFeatureAdapter::getUnformattedSpectrum(int *errorCode,
                    unsigned char *buffer, int bufferLength) {
    vector<unsigned char> *spectrum;
    int bytesCopied = 0;

    if(NULL == buffer) {
        SET_ERROR_CODE(ERROR_BAD_USER_BUFFER);
        return 0;
    }

    try {
        spectrum = this->feature->getUnformattedSpectrum(*this->protocol,
            *this->bus);
        int bytes = (int) spectrum->size();
        bytesCopied = (bytes < bufferLength) ? bytes : bufferLength;
        memcpy(buffer, &((*spectrum)[0]), bytesCopied * sizeof (unsigned char));
        delete spectrum;
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }

    return bytesCopied;
}


int SpectrometerFeatureAdapter::getFormattedSpectrum(int *errorCode,
                    double* buffer, int bufferLength) {
    vector<double> *spectrum;
    int doublesCopied = 0;

    if(NULL == buffer) {
        SET_ERROR_CODE(ERROR_BAD_USER_BUFFER);
        return 0;
    }

    try {
        spectrum = this->feature->getSpectrum(*this->protocol, *this->bus);
        int pixels = (int) spectrum->size();
        doublesCopied = (pixels < bufferLength) ? pixels : bufferLength;
        memcpy(buffer, &((*spectrum)[0]), doublesCopied * sizeof (double));
        delete spectrum;
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
    return doublesCopied;
}

int SpectrometerFeatureAdapter::getUnformattedSpectrumLength(int *errorCode) {
    /* This is, unfortunately, very hard to implement directly.
     * The readout length from the device is buried inside a particular
     * protocol message that would require a lot of digging to reach.
     * Since every protocol could have a different readout length,
     * this value cannot simply be stored in the spectrometer feature
     * like the number of pixels.
     *
     * This leaves two (not particularly nice) options.  The first is
     * to simply get an unformatted spectrum, check the length, and
     * throw it away.  The other is to create a lookup table of all
     * possible lengths based on the device type.  I am opting for
     * the former, even though it could have unpleasant side-effects.
     */
    vector<byte> *spectrum;

    try {
        spectrum = this->feature->getUnformattedSpectrum(
            *this->protocol, *this->bus);
        int length = (int) spectrum->size();
        delete spectrum;
        SET_ERROR_CODE(ERROR_SUCCESS);
        return length;
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
    return 0;
}


int SpectrometerFeatureAdapter::getFormattedSpectrumLength(int *errorCode) {
    int numberOfPixels = 0;

    try {
        numberOfPixels = this->feature->getNumberOfPixels();
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
    return numberOfPixels;
}

void SpectrometerFeatureAdapter::setTriggerMode(int *errorCode, int mode) {
    SpectrometerTriggerMode triggerMode(mode);

    try {
        this->feature->setTriggerMode(*this->protocol, *this->bus, triggerMode);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }
}


int SpectrometerFeatureAdapter::getWavelengths(int *errorCode,
        double *wavelengths, int length) {
    int valuesCopied = 0;
    int i;
    vector<double> *wlVector;
    vector<double>::iterator iter;

    try {
        wlVector = this->feature->getWavelengths(*this->protocol, *this->bus);
        /* It might be possible to do a memcpy() of the underlying vector into
         * the array, but that isn't the safest thing to do.  As long as this is
         * called once and the result cached, the inefficiency won't hurt.
         */
        for(iter = wlVector->begin(), i = 0;
                iter != wlVector->end() && i < length; iter++, i++) {
            wavelengths[i] = *iter;
            valuesCopied++;
        }

        delete wlVector;

        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
    return valuesCopied;
}

int SpectrometerFeatureAdapter::getElectricDarkPixelCount(int *errorCode) {
    vector<int> pixelVector;

    pixelVector = this->feature->getElectricDarkPixelIndices();

    SET_ERROR_CODE(ERROR_SUCCESS);
    return (int) pixelVector.size();
}

int SpectrometerFeatureAdapter::getElectricDarkPixelIndices(int *errorCode,
                    int *indices, int length) {
    int valuesCopied = 0;
    int i;
    vector<int> pixelVector;
    vector<int>::iterator iter;

    pixelVector = this->feature->getElectricDarkPixelIndices();

    /* It might be possible to do a memcpy() of the underlying vector into
     * the array, but that isn't the safest thing to do.  As long as this is
     * called once and the result cached, the inefficiency won't hurt.
     */
    for(iter = pixelVector.begin(), i = 0;
            iter != pixelVector.end() && i < length; iter++, i++) {
        indices[i] = *iter;
        valuesCopied++;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
    return valuesCopied;
}

void SpectrometerFeatureAdapter::setIntegrationTimeMicros(int *errorCode,
                    unsigned long integrationTimeMicros) {
    try {
        this->feature->setIntegrationTimeMicros(*this->protocol, *this->bus,
                    integrationTimeMicros);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }
}

long SpectrometerFeatureAdapter::getMinimumIntegrationTimeMicros(int *errorCode) {
    long retval = -1;

    try {
        retval = this->feature->getIntegrationTimeMinimum();
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return -1;
    }
    return retval;
}


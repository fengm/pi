/***************************************************//**
 * @file    ShutterFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze ShutterFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/ShutterFeatureAdapter.h"
#include <string.h> /* for memcpy */
#include <string>   

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;

ShutterFeatureAdapter::ShutterFeatureAdapter(
        ShutterFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<ShutterFeatureInterface>(intf, f, p, b, instanceIndex) {

    /* Nothing else to do here, the initialization list takes care of it */
}

ShutterFeatureAdapter::~ShutterFeatureAdapter() {
    /* This is just a wrapper around existing instances -- nothing to delete */
}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
void ShutterFeatureAdapter::setShutterOpen(int *errorCode, bool open) {

    try {
        this->feature->setShutterOpen(*this->protocol, *this->bus, open);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
}


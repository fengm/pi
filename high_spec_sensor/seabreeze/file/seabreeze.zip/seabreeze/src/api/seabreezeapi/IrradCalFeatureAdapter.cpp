/***************************************************//**
 * @file    IrradCalFeatureAdapter.h
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze IrradCalFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/IrradCalFeatureAdapter.h"
#include <string.h> /* for memcpy */
#include <vector>

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;

IrradCalFeatureAdapter::IrradCalFeatureAdapter(
        IrradCalFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<IrradCalFeatureInterface>(intf, f, p, b, instanceIndex) {

    /* Nothing else to do here, the initialization list takes care of it */
}

IrradCalFeatureAdapter::~IrradCalFeatureAdapter() {
    /* This is just a wrapper around existing instances -- nothing to delete */
}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
int IrradCalFeatureAdapter::readIrradCalibration(int *errorCode, float *buffer,
                    int bufferLength) {
    int floatsCopied = 0;

    vector<float> *cal;

    try {
        cal = this->feature->readIrradCalibration(*this->protocol, *this->bus);
        int floats = (int) cal->size();
        floatsCopied = (floats < bufferLength) ? floats : bufferLength;
        memcpy(buffer, &((*cal)[0]), floatsCopied * sizeof(float));

        delete cal;
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
    return floatsCopied;
}

int IrradCalFeatureAdapter::writeIrradCalibration(int *errorCode, float *buffer,
        int bufferLength) {
    int floatsCopied = 0;

    vector<float> *floatVector = new vector<float>;
    floatVector->resize(bufferLength);
    memcpy(&((*floatVector)[0]), buffer, bufferLength * sizeof(float));

    try {
        floatsCopied = this->feature->writeIrradCalibration(
            *this->protocol, *this->bus, *floatVector);
        delete floatVector;
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        delete floatVector;
        return 0;
    }

    return floatsCopied;
}

int IrradCalFeatureAdapter::hasIrradCollectionArea(int *errorCode) {
    int retval;

    /* hasCollectionArea() does not throw any exceptions. */
    retval = this->feature->hasCollectionArea(*this->protocol, *this->bus);
    SET_ERROR_CODE(ERROR_SUCCESS);
    return retval;
}

float IrradCalFeatureAdapter::readIrradCollectionArea(int *errorCode) {
    float area = 1.0;   /* Safe default since it removes area from calculations */

    try {
        area = (float) this->feature->readCollectionArea(*this->protocol, *this->bus);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
    }
    return area;
}

void IrradCalFeatureAdapter::writeIrradCollectionArea(int *errorCode, float area) {
    try {
        this->feature->writeCollectionArea(*this->protocol, *this->bus, area);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
    }
}



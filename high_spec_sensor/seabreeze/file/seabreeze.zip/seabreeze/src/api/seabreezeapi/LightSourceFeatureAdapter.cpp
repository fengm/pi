/***************************************************//**
 * @file    LightSourceFeatureAdapter.cpp
 * @date    May 2013
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2013 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze LightSourceFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/LightSourceFeatureAdapter.h"
#include <string.h> /* for memcpy */
#include <string>   

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;


#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif

LightSourceFeatureAdapter::LightSourceFeatureAdapter(
        LightSourceFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<LightSourceFeatureInterface>(intf, f, p, b, instanceIndex) {

    /* Nothing else to do here, the initialization list takes care of it */
}

LightSourceFeatureAdapter::~LightSourceFeatureAdapter() {
    /* This is just a wrapper around existing instances -- nothing to delete */
}


int LightSourceFeatureAdapter::getLightSourceCount(int *errorCode) {
    SET_ERROR_CODE(ERROR_SUCCESS);
    try {
        return this->feature->getLightSourceCount(*this->protocol, *this->bus);
    } catch (FeatureException &ex) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }
}

bool LightSourceFeatureAdapter::hasLightSourceEnable(int *errorCode,
            int lightSourceIndex) {
    SET_ERROR_CODE(ERROR_SUCCESS);
    try {
        return this->feature->hasLightSourceEnable(*this->protocol, *this->bus,
                        lightSourceIndex);
    } catch (FeatureException &ex) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return false;
    }
}


bool LightSourceFeatureAdapter::isLightSourceEnabled(int *errorCode,
            int lightSourceIndex) {
    SET_ERROR_CODE(ERROR_SUCCESS);
    try {
        return this->feature->isLightSourceEnabled(*this->protocol, *this->bus,
                        lightSourceIndex);
    } catch (FeatureException &ex) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return false;
    }
}


void LightSourceFeatureAdapter::setLightSourceEnable(int *errorCode,
            int lightSourceIndex, bool enable) {

    try {
        this->feature->setLightSourceEnable(*this->protocol, *this->bus,
                lightSourceIndex, enable);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
}


bool LightSourceFeatureAdapter::hasVariableIntensity(int *errorCode,
            int lightSourceIndex) {
    SET_ERROR_CODE(ERROR_SUCCESS);
    try {
        return this->feature->hasVariableIntensity(*this->protocol, *this->bus,
                        lightSourceIndex);
    } catch (FeatureException &ex) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return false;
    }
}


double LightSourceFeatureAdapter::getLightSourceIntensity(int *errorCode,
            int lightSourceIndex) {
    SET_ERROR_CODE(ERROR_SUCCESS);
    try {
        return this->feature->getLightSourceIntensity(*this->protocol,
                        *this->bus, lightSourceIndex);
    } catch (FeatureException &ex) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0.0;
    }
}


void LightSourceFeatureAdapter::setLightSourceIntensity(int *errorCode,
                    int lightSourceIndex, double intensity) {

    try {
        this->feature->setLightSourceIntensity(*this->protocol, *this->bus,
                lightSourceIndex, intensity);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
}

/***************************************************//**
 * @file    ContinuousStrobeFeatureAdapter.cpp
 * @date    October 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows access to SeaBreeze 
 * ContinuousStrobeFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"
#include "api/seabreezeapi/ContinuousStrobeFeatureAdapter.h"
#include <string.h> /* for memcpy */
#include <string>   

using namespace seabreeze;
using namespace seabreeze::api;
using namespace std;

ContinuousStrobeFeatureAdapter::ContinuousStrobeFeatureAdapter(
        ContinuousStrobeFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<ContinuousStrobeFeatureInterface>(intf, f, p, b, instanceIndex) {
}

ContinuousStrobeFeatureAdapter::~ContinuousStrobeFeatureAdapter() {
}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
void ContinuousStrobeFeatureAdapter::setContinuousStrobePeriodMicroseconds(int *errorCode,
        unsigned long period_usec) {

    try {
        this->feature->setContinuousStrobePeriodMicroseconds(*this->protocol, *this->bus, this->index, period_usec);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
}

void ContinuousStrobeFeatureAdapter::setContinuousStrobeEnable(int *errorCode,
        bool enable) {

    try {
        this->feature->setContinuousStrobeEnable(*this->protocol, *this->bus, this->index, enable);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    SET_ERROR_CODE(ERROR_SUCCESS);
}

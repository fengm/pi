/***************************************************//**
 * @file    ThermoElectricCoolerFeatureAdapter.cpp
 * @date    February 2012
 * @author  Ocean Optics, Inc.
 *
 * Copyright (C) 2012 Ocean Optics, Inc.
 * All rights reserved.
 *
 * Notes:
 *
 * This is a wrapper that allows
 * access to SeaBreeze TECFeatureInterface instances.
 *
 *******************************************************/

/* Macros and constants */
#define SET_ERROR_CODE(code) do { if(NULL != errorCode) { *errorCode = code; }  } while(0)

#include "common/globals.h"
#include "api/seabreezeapi/ThermoElectricCoolerFeatureAdapter.h"
#include "api/seabreezeapi/SeaBreezeAPIConstants.h"

using namespace seabreeze;
using namespace seabreeze::api;

ThermoElectricCoolerFeatureAdapter::ThermoElectricCoolerFeatureAdapter(
        ThermoElectricFeatureInterface *intf, const FeatureFamily &f,
                    Protocol *p, Bus *b, unsigned short instanceIndex)
        : FeatureAdapterTemplate<ThermoElectricFeatureInterface>(intf, f, p, b, instanceIndex) {

}

ThermoElectricCoolerFeatureAdapter::~ThermoElectricCoolerFeatureAdapter() {

}

#ifdef _WINDOWS
#pragma warning (disable: 4101) // unreferenced local variable
#endif
double ThermoElectricCoolerFeatureAdapter::readTECTemperature(int *errorCode) {
    double retval;

    try {
        retval = this->feature->getTemperatureCelsius(
            *this->protocol, *this->bus);
        SET_ERROR_CODE(ERROR_SUCCESS);
        return retval;
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return 0;
    }

    return 0;
}

void ThermoElectricCoolerFeatureAdapter::setTECTemperature(int *errorCode,
        double temperature_degrees_celsius) {

    try {
        this->feature->setTemperatureSetPointCelsius(*this->protocol, *this->bus,
                temperature_degrees_celsius);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    return;
}

void ThermoElectricCoolerFeatureAdapter::setTECEnable(int *errorCode,
        bool tec_enable) {
    try {
        this->feature->setThermoElectricEnable(*this->protocol, *this->bus, tec_enable);
        SET_ERROR_CODE(ERROR_SUCCESS);
    } catch (FeatureException &fe) {
        SET_ERROR_CODE(ERROR_TRANSFER_ERROR);
        return;
    }

    return;
}

void ThermoElectricCoolerFeatureAdapter::setTECFanEnable(int *errorCode,
        bool tec_fan_enable) {

    SET_ERROR_CODE(ERROR_NOT_IMPLEMENTED);
    /* FIXME: MISSING_IMPL */
    return;
}

[README.txt]

This is a simple demo of how to use SeaBreeze from Visual C++.

In this case, we used the object-oriented C++ API to SeaBreezeWrapper,
although the C API to SeaBreezeWrapper, or the C++ API to SeaBreezeAPI
should work as well.

Last tested:
    User: Mark Zieg
    OS: Windows 7 (32-bit)
    Compiler: Visual Studio 2010
    Spectrometer: Ventana

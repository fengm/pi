#include "util.h"
#include <sstream>

using std::stringstream;
using std::getline;
using std::string;
using std::vector;

// http://stackoverflow.com/a/236803
vector<string> &OOI::Util::split(const string &s, char delim, vector<string> &elems) 
{
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) 
        elems.push_back(item);
    return elems;
}

vector<string> OOI::Util::split(const string &s, char delim) 
{
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}
